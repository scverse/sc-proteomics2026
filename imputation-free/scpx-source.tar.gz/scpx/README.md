# scpx

**scplainer** and **omicsGMF** for single-cell proteomics, in Python. Two
imputation-free latent models ported from their Bioconductor originals, plus the
diagnostics that decide whether either result means anything.

Nothing in this package fills a missing value in order to fit. scplainer models
each feature on the cells that observed it; omicsGMF marginalises unobserved
entries through the model's own prediction inside the EM loop. Model-based
completion is available, clearly separated, and documented as a visualisation
output rather than something to feed a differential test.

## Install

```bash
pip install -e ".[dev]"      # numpy, pandas, scipy; matplotlib for plots
pytest -q                    # 38 tests
```

## Use

```python
import numpy as np, pandas as pd, scpx
from scpx import ScpModel, GMF
from scpx.diagnostics import detection_depth, component_confounding

Y = pd.read_csv("protein_by_cell.csv", index_col=0)   # log2, NaN for missing
depth = detection_depth(Y)
coldata = pd.DataFrame({
    "run": [c.split("_")[0] for c in Y.columns],
    "MedianIntensity": Y.median(axis=0).to_numpy(),
    "LogDepth": np.log2(depth.to_numpy()),
}, index=Y.columns)

# scplainer
m = ScpModel(Y, coldata, formula="~ 1 + LogDepth + MedianIntensity + run")
m.variance_analysis()                                   # where the variance goes
m.component_analysis(ncomp=8, method="APCA", effects=["run"])
m.differential_analysis("run", "227J1", "2308J3")       # observed values only

# omicsGMF
X = scpx.build_design(coldata, "~ 1 + LogDepth + MedianIntensity + run").X
g = GMF(Y, X=X, add_intercept=False)
fit, cv = g.fit_cv([1, 2, 3, 5, 8, 12, 16])             # rank by cross-validation
g.factors(); g.loadings(); g.impute()

# the check that matters
component_confounding(g.factors(), depth)
```

## What was ported, and how faithfully

Formulas were read out of the R sources, not the papers.

| | scplainer (`scp`) | omicsGMF |
|---|---|---|
| model | `Y = X beta + E` per feature, on observed cells | `mu = X B' + Gamma Z' + U V'` |
| penalty | ridge `lambda = 1e-3`, exact | small ridge for conditioning |
| factor coding | `contr.sum`, exact | n/a |
| variance | `SS_res + sum(SS_effects)` denominator, exact | n/a |
| components | APCA / ASCA / ASCA.E on effect (+ residuals), NIPALS or SVD | orthogonalised `U` |
| testing | t-test on `c'beta`, `se = sqrt(c' Vcov c)`, BH | n/a |
| rank | n/a | 3-fold CV masking 30% of observed entries |
| fitting | closed form | **alternating least squares, not SGD** |
| families | n/a | **Gaussian only** |

Three deliberate deviations, each defaulted to the safer behaviour and each
switchable back:

1. **`center_numeric=True`.** R's `model.matrix` does not centre numeric
   covariates. In proteomics the natural covariate is a per-cell median log2
   intensity of about 20, which makes `X'X` nearly singular. The `1e-3` ridge
   then perturbs the slope, and the variance decomposition attributes ~99.7% to
   that term purely because the column was not centred. On the Fulcher data,
   centring moves `MedianIntensity` from 99.7% to 3.9% of median explained
   variance. Set `center_numeric=False` for R-identical intercepts.
2. **`drop_rank_deficient=True`.** When a feature's observed cells do not span
   the design, the ridge still returns a fit in R and `n/p` can clear the
   threshold, but the contrast is not estimable from that feature. Set `False`
   for bit-compatibility.
3. **ALS instead of SGD** in `GMF`. Same model, same likelihood, same missing
   handling; different optimiser. Use the R package on very large matrices.

## What running it on a real dataset showed

Fulcher single-cell DIA, MaxLFQ protein x cell, 1984 x 126, 17.8% missing.

**With no covariates the two methods are the same method.** Canonical
correlations between the two 8-dimensional latent spaces: 0.999, 0.999, 0.999,
0.998, 0.997, 0.995, 0.97, 0.885. That is not a bug. With an intercept-only
design scplainer's APCA effect matrix is the observed data and its component
analysis is NIPALS PCA, while omicsGMF is a rank-8 Gaussian low-rank fit. On a
matrix this complete those coincide.

**The leading component is detection depth, and covariates do not fix it unless
you name depth.** |r| between the first component and log2 proteins-detected:

| design | scplainer | omicsGMF |
|---|---|---|
| `~ 1` | 0.87 | 0.90 |
| `~ 1 + run` | 0.82 | 0.87 |
| `~ 1 + MedianIntensity + run` | 0.89 | 0.91 |
| `~ 1 + LogDepth + MedianIntensity + run` | **0.02** | **0.00** |

Median intensity is not depth: on this dataset they correlate at −0.03.
Normalising on intensity leaves the depth axis completely intact. Batch does not
absorb it either. Only putting log depth in the design removes it, and then it is
gone in both methods.

**Model-completed matrices inflate differential hits.** Same contrast, same test,
768 proteins at FDR 5% on observed values only; 934 (+22%) through the omicsGMF
completion; 1216 (+58%) through a rank-8 reconstruction. Effect sizes barely move
(r = 0.98). What moves is within-group variance, because filled values sit on the
model's low-rank surface. Keep the DR object and the DE object separate.

**Even fully specified, the two methods agree.** With
`~ 1 + LogDepth + MedianIntensity + run` in both, canonical correlations between
omicsGMF factors and scplainer's residual space are 0.999 to 0.927. The choice
between the two packages matters far less than what is in the design matrix.

Reproduce with `examples/fulcher_validation.py` and
`examples/fulcher_covariates.py`.

## Layout

```
src/scpx/
  design.py         contr.sum model matrices, formula parsing, contrast vectors
  scplainer.py      ScpModel: fit, n/p filter, variance, components, differential
  gmf.py            GMF: Gaussian GMF with covariates, CV rank, imputation
  decomposition.py  NIPALS (missing-value tolerant) and SVD PCA
  diagnostics.py    depth confounding, detection rates, embedding comparison,
                    differential inflation
  plotting.py       CV curve, scores, variance, volcano on a CVD-validated palette
tests/              38 tests against known ground truth
examples/           the two Fulcher scripts
```

## Limits worth knowing

- NIPALS forms inner products over observed pairs. It is sound to roughly 20-30%
  missing; past that, components lose orthogonality and convergence degrades.
- Cross-validated rank selection can only hide entries that were observed, so it
  scores the MAR component. It says nothing about values missing because they
  fell below detection.
- Neither method identifies whether a missing value was absent or censored. No
  method does. That distinction is not recoverable from intensity data alone.
- Formulas support main effects only, matching the caveat in scp's own source.

## References

- Vanderaa & Gatto, scplainer, *Genome Biology* 2025.
- Segers et al., omicsGMF, *Nature Communications* 2026.
- Vanderaa & Gatto, *Revisiting the thorny issue of missing values in single-cell
  proteomics*, arXiv:2304.06654.
