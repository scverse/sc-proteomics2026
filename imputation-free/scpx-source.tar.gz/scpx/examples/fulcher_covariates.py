#!/usr/bin/env python3
"""Does modelling covariates actually remove the detection-depth axis?

Part 1 of the validation showed that with no covariates, factor 1 of both
methods correlates with per-cell detection depth at |r| ~ 0.9. The obvious
response is to put covariates in the model. This script tests whether that
works, using centred covariates and four designs of increasing ambition.
"""

from __future__ import annotations

import numpy as np
import pandas as pd

import scpx
from scpx import GMF, ScpModel
from scpx.diagnostics import compare_embeddings, component_confounding, detection_depth

CSV = "/home/claude/fulcher.csv"
D = 8


def main() -> None:
    Y = pd.read_csv(CSV, index_col=0)
    depth = detection_depth(Y)
    cd = pd.DataFrame({
        "run": [c.split("_")[0] for c in Y.columns],
        "MedianIntensity": Y.median(axis=0, skipna=True).to_numpy(),
        "LogDepth": np.log2(depth.to_numpy().astype(float)),
    }, index=Y.columns)

    designs = {
        "~ 1": "~ 1",
        "~ 1 + run": "~ 1 + run",
        "~ 1 + MedianIntensity + run": "~ 1 + MedianIntensity + run",
        "~ 1 + LogDepth + MedianIntensity + run": "~ 1 + LogDepth + MedianIntensity + run",
    }

    print(f"{Y.shape[0]} proteins x {Y.shape[1]} cells | "
          f"corr(MedianIntensity, log2 depth) = "
          f"{np.corrcoef(cd['MedianIntensity'], cd['LogDepth'])[0, 1]:+.2f}\n")

    rows, var_rows = [], []
    for label, f in designs.items():
        m = ScpModel(Y, cd, formula=f)          # numeric covariates centred
        ca = m.component_analysis(ncomp=D, method="APCA", effects=[], pca_fun="nipals")
        res = pd.DataFrame(ca["residuals"].scores, index=Y.columns,
                           columns=ca["residuals"].names)
        conf = component_confounding(res, depth)

        v = (m.variance_analysis()
             .groupby("effect")["percent_explained_var"].median())
        for eff, pct in v.items():
            var_rows.append({"design": label, "effect": eff, "median_pct": pct})

        rows.append({
            "design": label, "p": m.design.n_params,
            "features_kept": len(m.kept_features),
            "|r| PC1 vs depth": abs(conf["r_depth"].iloc[0]),
            "max |r| PC1-3": conf["r_depth"].abs().head(3).max(),
        })
        print(f"{label:<42s} p={m.design.n_params}  "
              f"kept={len(m.kept_features):4d}  "
              f"|r(PC1, depth)|={abs(conf['r_depth'].iloc[0]):.2f}")

    print("\nscplainer: median % variance explained per term")
    vt = (pd.DataFrame(var_rows)
          .pivot(index="design", columns="effect", values="median_pct")
          .reindex(list(designs)))
    print(vt.to_string(float_format=lambda x: f"{x:.1f}" if np.isfinite(x) else "-"))

    print("\nsummary of the depth axis under scplainer")
    print(pd.DataFrame(rows).to_string(index=False,
                                       float_format=lambda x: f"{x:.2f}"))

    # ---- omicsGMF, same information, centred -----------------------------
    print("\nomicsGMF with the same covariates in X")
    gmf_rows = []
    for label, f in designs.items():
        Xd = scpx.build_design(cd, f)           # centred
        g = GMF(Y, X=Xd.X, add_intercept=False)
        fit = g.fit(d=D, max_iter=600, tol=1e-8)
        conf = component_confounding(g.factors(), depth)
        gmf_rows.append({
            "design": label, "converged": fit.converged, "iters": fit.n_iter,
            "|r| F1 vs depth": abs(conf["r_depth"].iloc[0]),
            "max |r| F1-3": conf["r_depth"].abs().head(3).max(),
        })
        print(f"  {label:<42s} |r(F1, depth)|="
              f"{abs(conf['r_depth'].iloc[0]):.2f}  "
              f"converged={fit.converged} ({fit.n_iter} it)")
    pd.DataFrame(gmf_rows).to_csv("covariate_sweep_gmf.csv", index=False)
    pd.DataFrame(rows).to_csv("covariate_sweep_scplainer.csv", index=False)
    vt.to_csv("covariate_sweep_variance.csv")

    # ---- the point ---------------------------------------------------------
    print("\n" + "-" * 72)
    full = ScpModel(Y, cd, designs["~ 1 + LogDepth + MedianIntensity + run"])
    ca = full.component_analysis(ncomp=D, method="APCA", effects=[], pca_fun="nipals")
    res = pd.DataFrame(ca["residuals"].scores, index=Y.columns, columns=ca["residuals"].names)
    Xd = scpx.build_design(cd, designs["~ 1 + LogDepth + MedianIntensity + run"])
    g = GMF(Y, X=Xd.X, add_intercept=False)
    g.fit(d=D, max_iter=600, tol=1e-8)
    cc = compare_embeddings(g.factors(), res, k=D)
    print(f"canonical correlations, fully-specified omicsGMF vs scplainer residuals:\n"
          f"  {np.round(cc, 3)}")


if __name__ == "__main__":
    main()
