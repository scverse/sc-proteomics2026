#!/usr/bin/env python3
"""Validate scpx on the Fulcher single-cell DIA matrix, and run the version
that the no-covariate comparison could not.

Part 1 reproduces the earlier no-covariate result, which is the check that the
package computes the same thing the standalone scripts did.

Part 2 is the analysis worth having: both methods with acquisition run and
per-cell median intensity in the model. That is the only configuration where
scplainer and omicsGMF do different things, because it is the only one where
scplainer has a design matrix to partition.
"""

from __future__ import annotations

import numpy as np
import pandas as pd

import scpx
from scpx import GMF, ScpModel
from scpx.diagnostics import (compare_embeddings, component_confounding,
                              detection_depth, differential_inflation)

CSV = "/home/claude/fulcher.csv"
RANKS = [1, 2, 3, 5, 8, 12, 16, 20, 25]


def main() -> None:
    Y = pd.read_csv(CSV, index_col=0)
    depth = detection_depth(Y)
    coldata = pd.DataFrame({
        "run": [c.split("_")[0] for c in Y.columns],
        "session": ["227" if c.startswith("227") else "2308" for c in Y.columns],
        "MedianIntensity": Y.median(axis=0, skipna=True).to_numpy(),
        "depth": depth.to_numpy(),
    }, index=Y.columns)
    print(f"{Y.shape[0]} proteins x {Y.shape[1]} cells, "
          f"{100 * Y.isna().to_numpy().mean():.1f}% missing")
    print(coldata["run"].value_counts().to_string(), "\n")

    out: dict[str, object] = {}

    # ---------------------------------------------------------------- PART 1
    print("=" * 72)
    print("PART 1  no covariates (reproduces the earlier scripts)")
    print("=" * 72)

    g0 = GMF(Y)
    fit0, cv0 = g0.fit_cv(RANKS, n_folds=3, hold_frac=0.30, max_iter=80, seed=1)
    print(f"\nomicsGMF CV-selected rank d = {cv0.best_rank}")
    print(cv0.to_frame().to_string(index=False, float_format=lambda v: f"{v:.4f}"))

    s0 = ScpModel(Y, coldata, formula="~ 1")
    ca0 = s0.component_analysis(ncomp=8, method="APCA", pca_fun="nipals")
    scp0 = pd.DataFrame(ca0["unmodelled"].scores, index=Y.columns,
                        columns=ca0["unmodelled"].names)
    print(f"\nscplainer ~1: {len(s0.kept_features)}/{len(s0.features)} features kept "
          f"(n/p >= 1); design columns {s0.design.columns}")

    conf0 = pd.concat([
        component_confounding(g0.factors(), depth).rename(
            columns={"r_depth": "omicsGMF"})["omicsGMF"],
        component_confounding(scp0, depth).rename(
            columns={"r_depth": "scplainer"})["scplainer"].set_axis(
                g0.factors().columns[:8]),
    ], axis=1)
    print("\ncorrelation of each component with log2 detection depth:")
    print(conf0.head(6).to_string(float_format=lambda v: f"{v:+.2f}"))

    cc0 = compare_embeddings(g0.factors(), scp0, k=8)
    print(f"\ncanonical correlations, the two 8-d spaces:\n  {np.round(cc0, 3)}")

    inflation = differential_inflation(
        Y,
        {"omicsGMF completed": g0.impute(),
         "scplainer completed": pd.DataFrame(
             (ca0["unmodelled"].scores @ ca0["unmodelled"].eigenvectors.T).T
             + s0.intercepts().reindex(s0.kept_features).to_numpy()[:, None],
             index=s0.kept_features, columns=Y.columns)},
        coldata["session"],
    )
    print("\ndifferential hits, 227 vs 2308 (technical contrast), FDR 5%:")
    print(inflation.to_string(index=False, float_format=lambda v: f"{v:.3f}"))
    out.update(cv0=cv0, conf0=conf0, cc0=cc0, inflation=inflation)

    # ---------------------------------------------------------------- PART 2
    print("\n" + "=" * 72)
    print("PART 2  with covariates: ~ 1 + MedianIntensity + run")
    print("=" * 72)

    s1 = ScpModel(Y, coldata, formula="~ 1 + MedianIntensity + run")
    print(f"\nscplainer: design {s1.design.columns}")
    print(f"  {len(s1.kept_features)}/{len(s1.features)} features kept at n/p >= 1 "
          f"(p = {s1.design.n_params})")

    var = s1.variance_analysis()
    med = (var.groupby("effect")["percent_explained_var"]
           .median().sort_values(ascending=False))
    print("\nmedian % variance explained per model term:")
    print(med.to_string(float_format=lambda v: f"{v:.1f}"))

    ca1 = s1.component_analysis(ncomp=8, method="APCA", effects=["run"],
                                pca_fun="nipals")
    scp1_run = pd.DataFrame(ca1["APCA_run"].scores, index=Y.columns,
                            columns=ca1["APCA_run"].names)
    scp1_res = pd.DataFrame(ca1["residuals"].scores, index=Y.columns,
                            columns=ca1["residuals"].names)

    # omicsGMF with the same information in X
    Xd = scpx.build_design(coldata, "~ 1 + MedianIntensity + run")
    g1 = GMF(Y, X=Xd.X, add_intercept=False)
    fit1 = g1.fit(d=cv0.best_rank, max_iter=400)
    print(f"\nomicsGMF with X = {Xd.columns}: d = {fit1.d}, "
          f"converged={fit1.converged} in {fit1.n_iter} iterations")

    conf1 = pd.concat([
        component_confounding(g1.factors(), depth).rename(
            columns={"r_depth": "omicsGMF + covariates"})["omicsGMF + covariates"],
        component_confounding(scp1_res, depth).rename(
            columns={"r_depth": "scplainer residual PCA"}
        )["scplainer residual PCA"].set_axis(g1.factors().columns[:8]),
        component_confounding(scp1_run, depth).rename(
            columns={"r_depth": "scplainer APCA(run)"}
        )["scplainer APCA(run)"].set_axis(g1.factors().columns[:8]),
    ], axis=1)
    print("\ncorrelation with log2 detection depth, after modelling:")
    print(conf1.head(6).to_string(float_format=lambda v: f"{v:+.2f}"))

    cc1 = compare_embeddings(g1.factors(), scp1_res, k=8)
    print(f"\ncanonical correlations, omicsGMF vs scplainer residual space:"
          f"\n  {np.round(cc1, 3)}")

    da = s1.differential_analysis("run", "227J1", "2308J3")
    n_sig = int((da["padj"] < 0.05).sum())
    print(f"\nscplainer differential 227J1 vs 2308J3 (observed values only): "
          f"{n_sig}/{len(da)} at FDR 5%")
    print(da.nsmallest(5, "padj")[
        ["feature", "estimate", "se", "t", "padj", "n_obs"]
    ].to_string(index=False, float_format=lambda v: f"{v:.3g}"))

    out.update(s1=s1, g1=g1, var=var, conf1=conf1, cc1=cc1, da=da,
               scp1_run=scp1_run, scp1_res=scp1_res, g0=g0, scp0=scp0,
               coldata=coldata, depth=depth, Y=Y)

    # persist for the figure script
    np.savez(
        "fulcher_scpx.npz",
        cells=np.array(Y.columns), run=coldata["run"].to_numpy().astype(str),
        session=coldata["session"].to_numpy().astype(str),
        depth=depth.to_numpy(), ranks=np.array(RANKS), cv_scores=cv0.scores,
        d_opt=cv0.best_rank,
        gmf0=g0.factors().to_numpy(), scp0=scp0.to_numpy(),
        gmf1=g1.factors().to_numpy(), scp1_res=scp1_res.to_numpy(),
        scp1_run=scp1_run.to_numpy(),
        cc0=cc0, cc1=cc1,
        var_effect=var["effect"].to_numpy().astype(str),
        var_pct=var["percent_explained_var"].to_numpy(),
        da_feature=da["feature"].to_numpy().astype(str),
        da_est=da["estimate"].to_numpy(), da_padj=da["padj"].to_numpy(),
        infl_names=inflation["matrix"].to_numpy().astype(str),
        infl_n=inflation["n_significant"].to_numpy(),
    )
    print("\nsaved fulcher_scpx.npz")
    return out


if __name__ == "__main__":
    main()
