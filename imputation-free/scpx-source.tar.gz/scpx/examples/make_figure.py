#!/usr/bin/env python3
"""One figure: what the covariate sweep did to the depth axis."""

from __future__ import annotations

import numpy as np
import pandas as pd

import scpx
from scpx import GMF, ScpModel
from scpx.diagnostics import compare_embeddings, component_confounding, detection_depth

from scpx import plotting as P

CSV = "/home/claude/fulcher.csv"
D = 8
DESIGNS = {
    "~ 1": "~ 1",
    "~ 1 + run": "~ 1 + run",
    "~ 1 + MedInt + run": "~ 1 + MedianIntensity + run",
    "~ 1 + LogDepth\n     + MedInt + run": "~ 1 + LogDepth + MedianIntensity + run",
}


def main() -> None:
    import matplotlib.pyplot as plt
    P.apply_style()

    Y = pd.read_csv(CSV, index_col=0)
    depth = detection_depth(Y)
    cd = pd.DataFrame({
        "run": [c.split("_")[0] for c in Y.columns],
        "session": ["227" if c.startswith("227") else "2308" for c in Y.columns],
        "MedianIntensity": Y.median(axis=0, skipna=True).to_numpy(),
        "LogDepth": np.log2(depth.to_numpy().astype(float)),
    }, index=Y.columns)

    scp_r, gmf_r, var_tab = [], [], []
    first_scores, last_scores = {}, {}
    for label, f in DESIGNS.items():
        m = ScpModel(Y, cd, formula=f)
        ca = m.component_analysis(ncomp=D, method="APCA", effects=[], pca_fun="nipals")
        res = pd.DataFrame(ca["residuals"].scores, index=Y.columns,
                           columns=ca["residuals"].names)
        scp_r.append(abs(component_confounding(res, depth)["r_depth"].iloc[0]))
        v = m.variance_analysis().groupby("effect")["percent_explained_var"].median()
        var_tab.append(v.rename(label))

        X = scpx.build_design(cd, f).X
        g = GMF(Y, X=X, add_intercept=False)
        g.fit(d=D, max_iter=500, tol=1e-7)
        gmf_r.append(abs(component_confounding(g.factors(), depth)["r_depth"].iloc[0]))

        if label == list(DESIGNS)[0]:
            first_scores = {"scp": res, "gmf": g.factors()}
        if label == list(DESIGNS)[-1]:
            last_scores = {"scp": res, "gmf": g.factors(),
                           "cc": compare_embeddings(g.factors(), res, k=D)}
        print(f"{label!r:<34s} scp {scp_r[-1]:.2f}  gmf {gmf_r[-1]:.2f}", flush=True)

    fig, ax = plt.subplots(2, 3, figsize=(12, 6.8))
    fig.suptitle("scpx on the Fulcher matrix: only naming depth removes the depth axis",
                 x=0.008, ha="left", fontsize=12, fontweight="bold", y=0.985)

    # a: the sweep
    a = ax[0, 0]
    idx = np.arange(len(DESIGNS))
    w = 0.38
    a.bar(idx - w / 2 - 0.01, scp_r, width=w, color=P.PALETTE[0], label="scplainer", zorder=3)
    a.bar(idx + w / 2 + 0.01, gmf_r, width=w, color=P.PALETTE[1], label="omicsGMF", zorder=3)
    a.axhline(0.4, color=P.INK2, lw=1, ls="--", zorder=4)
    a.set_xticks(idx)
    a.set_xticklabels(list(DESIGNS), fontsize=6, rotation=18, ha="right")
    a.set_ylim(0, 1.0)
    a.legend(loc="upper right")
    for i, (s, gg) in enumerate(zip(scp_r, gmf_r)):
        a.text(i - w / 2 - 0.01, s + 0.02, f"{s:.2f}", ha="center", fontsize=6, color=P.INK2)
        a.text(i + w / 2 + 0.01, gg + 0.02, f"{gg:.2f}", ha="center", fontsize=6, color=P.INK2)
    a.set_title("a  |r| of component 1 with log2 depth", loc="left", pad=6)
    a.set_ylabel("|r|")
    a.grid(True, alpha=0.7, zorder=0); a.set_axisbelow(True)

    # b: variance table
    a = ax[0, 1]
    V = pd.concat(var_tab, axis=1).T.reindex(columns=["Residuals", "LogDepth",
                                                      "MedianIntensity", "run"])
    bottom = np.zeros(len(V))
    cols = {"Residuals": P.INK3, "LogDepth": P.PALETTE[0],
            "MedianIntensity": P.PALETTE[1], "run": P.PALETTE[2]}
    for c in V.columns:
        vals = V[c].fillna(0).to_numpy()
        a.bar(np.arange(len(V)), vals, bottom=bottom, color=cols[c], width=0.62,
              label=c, zorder=3, edgecolor=P.SURFACE, linewidth=1.2)
        bottom += vals
    a.set_xticks(np.arange(len(V)))
    a.set_xticklabels(list(DESIGNS), fontsize=6, rotation=18, ha="right")
    a.legend(loc="upper left", fontsize=6)
    a.set_title("b  scplainer variance partition\n     (median % per feature)",
                loc="left", pad=6)
    a.set_ylabel("median % explained")
    a.grid(True, alpha=0.7, zorder=0); a.set_axisbelow(True)

    # c: canonical correlations, fully specified
    a = ax[0, 2]
    cc = last_scores["cc"]
    a.bar(np.arange(1, len(cc) + 1), cc, color=P.PALETTE[0], width=0.62, zorder=3)
    a.axhline(1.0, color=P.INK3, lw=0.8, ls=":", zorder=2)
    a.set_ylim(0, 1.1)
    for i, v in enumerate(cc):
        a.text(i + 1, v + 0.02, f"{v:.3f}", ha="center", fontsize=5.5, color=P.INK2)
    a.set_xticks(np.arange(1, len(cc) + 1))
    a.set_title("c  omicsGMF vs scplainer, full design\n     (canonical correlations)",
                loc="left", pad=6)
    a.set_xlabel("canonical dimension"); a.set_ylabel("correlation")
    a.grid(True, alpha=0.7, zorder=0); a.set_axisbelow(True)

    # d/e: before and after, coloured by depth
    for col, (key, ttl) in enumerate([("gmf", "omicsGMF"), ("scp", "scplainer")]):
        a = ax[1, col]
        s = first_scores[key]
        P.plot_scores(s, continuous=depth, ax=a, title=f"{'de'[col]}  {ttl}, ~ 1",
                      cbar_label="proteins detected")

    a = ax[1, 2]
    s = last_scores["gmf"]
    P.plot_scores(s, continuous=depth, ax=a,
                  title="f  omicsGMF, full design", cbar_label="proteins detected")

    fig.tight_layout(rect=[0, 0.02, 1, 0.955])
    fig.text(0.008, 0.008,
             "scpx: Python ports of the scplainer and omicsGMF models. "
             "Numeric covariates centred; see README for the three documented "
             "deviations from the R packages.", fontsize=6.5, color=P.INK3)
    fig.savefig("scpx_covariate_sweep.png", dpi=200)
    print("wrote scpx_covariate_sweep.png")


if __name__ == "__main__":
    main()
