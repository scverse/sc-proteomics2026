"""scpx - scplainer and omicsGMF for single-cell proteomics, in Python.

Two imputation-free latent models ported from their Bioconductor originals:

- :class:`~scpx.scplainer.ScpModel` - per-feature ridge regression fitted only on
  observed cells, ANOVA-style variance partitioning, APCA/ASCA component
  analysis, contrast-based differential abundance. Ported from ``scp``.
- :class:`~scpx.gmf.GMF` - Gaussian generalized matrix factorization with sample
  and feature covariates and cross-validated rank. Ported from ``omicsGMF``.

Plus :mod:`scpx.diagnostics`, which answers the two questions that decide whether
either result means anything: is the leading component detection depth, and how
many differential hits does a model-completed matrix invent.

Quick start
-----------
>>> import pandas as pd, scpx
>>> Y = pd.read_csv("protein_by_cell.csv", index_col=0)   # log2, NaN for missing
>>> coldata = pd.DataFrame({
...     "run": [c.split("_")[0] for c in Y.columns],
...     "MedianIntensity": Y.median(axis=0).values,
... }, index=Y.columns)
>>> model = scpx.ScpModel(Y, coldata, formula="~ 1 + MedianIntensity + run")
>>> var = model.variance_analysis()
>>> comps = model.component_analysis(ncomp=5, method="APCA")
>>> da = model.differential_analysis("run", "227J1", "2308J3")

>>> gmf = scpx.GMF(Y, X=None, Z=None)
>>> fit, cv = gmf.fit_cv([1, 2, 3, 5, 8, 12])
>>> scpx.diagnostics.component_confounding(
...     gmf.factors(), scpx.diagnostics.detection_depth(Y))
"""

from . import diagnostics, plotting
from .decomposition import PCAResult, auto_pca, nipals, svd_pca
from .design import DesignMatrix, build_design, parse_formula
from .gmf import GMF, CVResult, GMFFit
from .scplainer import FeatureFit, ScpModel, benjamini_hochberg

__version__ = "0.1.0"

__all__ = [
    "ScpModel", "FeatureFit", "benjamini_hochberg",
    "GMF", "GMFFit", "CVResult",
    "nipals", "svd_pca", "auto_pca", "PCAResult",
    "build_design", "parse_formula", "DesignMatrix",
    "diagnostics", "plotting", "__version__",
]
