"""PCA backends that tolerate missing values.

``nipals`` is a port of ``nipals::nipals()`` as scplainer calls it, including the
orientation and normalisation choices in scp's ``.nipalsWrapper()``:

* the input is **features x samples**;
* NIPALS runs on the transpose (samples x features) with features centred;
* scores are ``t_h`` (already scaled by the singular value);
* eigenvalues are ``eig^2 / (n_features - 1)``;
* ``proportion_variance`` is ``eig^2 / TSS`` of the centred matrix.

NIPALS forms every inner product over observed entries only, so no value is ever
imputed. That is also its weakness: at high missingness each loading is estimated
from a different effective subset, successive components lose orthogonality and
convergence degrades. It is well behaved up to roughly 20-30% missing and should
not be trusted far beyond that.
"""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np

__all__ = ["PCAResult", "nipals", "svd_pca", "auto_pca"]


@dataclass
class PCAResult:
    scores: np.ndarray             # samples x ncomp
    eigenvectors: np.ndarray       # features x ncomp
    eigenvalues: np.ndarray        # ncomp
    proportion_variance: np.ndarray  # ncomp
    n_iter: np.ndarray             # ncomp, iterations used per component
    converged: np.ndarray          # ncomp, bool

    @property
    def names(self) -> list[str]:
        return [f"PC{i + 1}" for i in range(self.scores.shape[1])]


def _centre_scale(A: np.ndarray, center: bool, scale: bool):
    """Centre/scale columns of ``A`` (samples x features) ignoring NaN."""
    A = A.astype(float, copy=True)
    mu = np.zeros(A.shape[1])
    sd = np.ones(A.shape[1])
    if center:
        mu = np.nanmean(A, axis=0)
        mu = np.where(np.isfinite(mu), mu, 0.0)
        A = A - mu
    if scale:
        sd = np.nanstd(A, axis=0, ddof=1)
        sd = np.where(np.isfinite(sd) & (sd > 0), sd, 1.0)
        A = A / sd
    return A, mu, sd


def nipals(
    mat: np.ndarray,
    ncomp: int = 2,
    center: bool = True,
    scale: bool = False,
    max_iter: int = 500,
    tol: float = 1e-6,
) -> PCAResult:
    """NIPALS PCA on a features x samples matrix containing NaN.

    Mirrors ``scp:::.nipalsWrapper()``. Features with no observed value are
    dropped before fitting, as in the R wrapper; their loadings come back as 0.
    """
    mat = np.asarray(mat, dtype=float)
    n_feat, n_samp = mat.shape
    if ncomp > min(n_feat, n_samp):
        raise ValueError("ncomp cannot exceed min(n_features, n_samples)")

    keep = np.isfinite(mat).sum(axis=1) > 0
    A, _, _ = _centre_scale(mat[keep].T, center, scale)   # samples x features
    obs = np.isfinite(A)
    A0 = np.where(obs, A, 0.0)
    tss = float(np.sum(A0**2))

    n, p = A.shape
    T = np.zeros((n, ncomp))
    P = np.zeros((p, ncomp))
    eig = np.zeros(ncomp)
    iters = np.zeros(ncomp, dtype=int)
    conv = np.zeros(ncomp, dtype=bool)

    work = A.copy()
    obs_f = obs.astype(float)
    for h in range(ncomp):
        # scp overrides nipals' default start: use the column with the most
        # observed values rather than the largest absolute sum.
        start = int(np.argmax(obs.sum(axis=0)))
        t = np.where(obs[:, start], work[:, start], 0.0).astype(float)
        if not np.any(t):
            t = np.where(obs.any(axis=1), 1.0, 0.0)

        pvec = np.zeros(p)
        for it in range(1, max_iter + 1):
            W = np.where(obs, work, 0.0)
            num = t @ W
            den = (t**2) @ obs_f
            pvec = np.divide(num, den, out=np.zeros(p), where=den > 0)
            nrm = np.linalg.norm(pvec)
            if nrm == 0:
                break
            pvec /= nrm
            num_t = W @ pvec
            den_t = obs_f @ (pvec**2)
            t_new = np.divide(num_t, den_t, out=np.zeros(n), where=den_t > 0)
            delta = np.linalg.norm(t_new - t) / max(np.linalg.norm(t_new), 1e-300)
            t = t_new
            iters[h] = it
            if delta < tol:
                conv[h] = True
                break

        T[:, h] = t
        P[:, h] = pvec
        eig[h] = np.linalg.norm(t)
        work = np.where(obs, work - np.outer(t, pvec), np.nan)

    eigenvectors = np.zeros((n_feat, ncomp))
    eigenvectors[keep] = P
    denom = max(keep.sum() - 1, 1)
    return PCAResult(
        scores=T,
        eigenvectors=eigenvectors,
        eigenvalues=eig**2 / denom,
        proportion_variance=(eig**2 / tss) if tss > 0 else np.zeros(ncomp),
        n_iter=iters,
        converged=conv,
    )


def svd_pca(mat: np.ndarray, ncomp: int = 2, center: bool = True,
            scale: bool = False) -> PCAResult:
    """Exact PCA via SVD. Mirrors ``scp:::.svdWrapper()``. No NaN allowed."""
    mat = np.asarray(mat, dtype=float)
    if np.isnan(mat).any():
        raise ValueError("svd_pca cannot handle missing values; use nipals")
    n_feat, n_samp = mat.shape
    if ncomp > min(n_feat, n_samp):
        raise ValueError("ncomp cannot exceed min(n_features, n_samples)")

    A, _, _ = _centre_scale(mat.T, center, scale)
    U, d, Vt = np.linalg.svd(A, full_matrices=False)
    eigenvalues = d**2 / max(n_feat - 1, 1)
    return PCAResult(
        scores=(U * d)[:, :ncomp],
        eigenvectors=Vt.T[:, :ncomp],
        eigenvalues=eigenvalues[:ncomp],
        proportion_variance=(d**2 / np.sum(d**2))[:ncomp],
        n_iter=np.zeros(ncomp, dtype=int),
        converged=np.ones(ncomp, dtype=bool),
    )


def auto_pca(mat: np.ndarray, ncomp: int = 2, **kw) -> PCAResult:
    """``nipals`` when the matrix has NaN, ``svd_pca`` otherwise (scp's default)."""
    return (nipals if np.isnan(np.asarray(mat, dtype=float)).any() else svd_pca)(
        mat, ncomp=ncomp, **kw
    )
