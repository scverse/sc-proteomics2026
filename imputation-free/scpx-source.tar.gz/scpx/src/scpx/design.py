"""R-compatible model matrices with sum-to-zero (``contr.sum``) coding.

scplainer builds its design with ``model.matrix(formula, contrasts.arg =
list(<each factor> = "contr.sum"))``. That choice is not cosmetic: sum coding
makes every factor's effect matrix mean-zero, which is what lets the ANOVA-style
variance decomposition and the APCA effect matrices be interpreted independently
of which level happens to be first. This module reproduces it exactly so the
Python coefficients are comparable to the R ones.

Under ``contr.sum`` a factor with k levels contributes k-1 columns. Level i
(1-indexed, i < k) is coded 1 in column i and 0 elsewhere; the *last* level is
coded -1 in every column. The dropped level's effect is therefore
``-sum(beta)`` over that factor's coefficients.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field

import numpy as np
import pandas as pd

__all__ = ["DesignMatrix", "build_design", "parse_formula"]


def parse_formula(formula: str) -> tuple[bool, list[str]]:
    """Parse a minimal R-style formula.

    Supports ``~ 1 + a + b``, ``~ a + b`` (intercept implied), ``~ 0 + a`` and
    ``~ a - 1`` (both drop the intercept). Interactions are not supported;
    scplainer's effect bookkeeping assumes main effects only and the R package
    carries the same caveat in its source comments.
    """
    rhs = formula.split("~", 1)[1] if "~" in formula else formula
    rhs = rhs.replace("-", "+ -")
    terms = [re.sub(r"\s+", "", t) for t in rhs.split("+") if t.strip()]

    intercept = True
    variables: list[str] = []
    for t in terms:
        if t in {"1"}:
            intercept = True
        elif t in {"0", "-1"}:
            intercept = False
        elif t.startswith("-"):
            raise ValueError(f"cannot remove term {t!r}; only -1 is supported")
        else:
            if t in variables:
                raise ValueError(f"duplicate term {t!r} in formula")
            variables.append(t)
    if not intercept and not variables:
        raise ValueError("formula has no terms")
    return intercept, variables


@dataclass
class DesignMatrix:
    """A model matrix plus the bookkeeping scplainer needs.

    Attributes
    ----------
    X
        ``(n_samples, n_params)`` array.
    columns
        Column names, R-style (``"run1"``, ``"run2"``, ``"MedianIntensity"``).
    assign
        For each column, the name of the variable it belongs to. The intercept
        is assigned ``"(Intercept)"``.
    levels
        For each categorical variable, its level order. The last level is the
        one absorbed by sum coding.
    """

    X: np.ndarray
    columns: list[str]
    assign: list[str]
    levels: dict[str, list[str]] = field(default_factory=dict)
    index: pd.Index | None = None

    @property
    def n_params(self) -> int:
        return self.X.shape[1]

    def columns_for(self, variable: str) -> np.ndarray:
        """Indices of the columns belonging to ``variable``."""
        return np.array([i for i, a in enumerate(self.assign) if a == variable], dtype=int)

    @property
    def variables(self) -> list[str]:
        seen = []
        for a in self.assign:
            if a != "(Intercept)" and a not in seen:
                seen.append(a)
        return seen

    def contrast(self, variable: str, level_a: str, level_b: str) -> np.ndarray:
        """Contrast vector for ``level_a - level_b``, in full coefficient space.

        Handles the sum-coded level correctly: the absorbed (last) level has
        coding -1 in every column of that variable.
        """
        if variable not in self.levels:
            raise ValueError(f"{variable!r} is not a categorical variable in this design")
        levs = self.levels[variable]
        for lv in (level_a, level_b):
            if lv not in levs:
                raise ValueError(f"level {lv!r} not in {variable}: {levs}")
        cols = self.columns_for(variable)

        def code(level: str) -> np.ndarray:
            row = np.zeros(len(cols))
            i = levs.index(level)
            if i == len(levs) - 1:
                row[:] = -1.0
            else:
                row[i] = 1.0
            return row

        c = np.zeros(self.n_params)
        c[cols] = code(level_a) - code(level_b)
        return c


def _is_categorical(s: pd.Series) -> bool:
    """Anything that is not numeric is coded as a factor.

    Checked positively rather than by listing dtypes: pandas 3 gives plain
    string columns a ``StringDtype`` rather than ``object``, and an
    ``s.dtype == object`` test silently sends them down the numeric path.
    """
    if isinstance(s.dtype, pd.CategoricalDtype):
        return True
    if pd.api.types.is_bool_dtype(s):
        return True
    return not pd.api.types.is_numeric_dtype(s)


def build_design(
    coldata: pd.DataFrame,
    formula: str,
    drop_unused_levels: bool = True,
    center_numeric: bool = True,
) -> DesignMatrix:
    """Build a ``contr.sum``-coded model matrix from sample annotations.

    Parameters
    ----------
    coldata
        One row per sample (cell). Index is used as the sample identifier.
    formula
        R-style, e.g. ``"~ 1 + MedianIntensity + run"``.
    drop_unused_levels
        Mirrors R's ``droplevels()``; unused categorical levels are removed
        before coding, as scplainer does.
    center_numeric
        Subtract the mean from every numeric covariate. Default True; R's
        ``model.matrix`` does not do this.

        Why the default differs from R: the natural numeric covariate in
        proteomics is a per-cell median log2 intensity, which sits around 20.
        Its effect matrix ``X[:, col] * beta`` then has entries around 20 while
        residuals are around 0.3, so the ANOVA-style decomposition attributes
        ~99.7% of the variance to that term purely because the column was not
        centred. Centring is free: for a least-squares fit it changes only the
        intercept, leaving residuals, factor coefficients and every contrast
        bit-identical, while making the variance decomposition mean what it
        appears to mean. Set False for R-identical intercepts.
    """
    intercept, variables = parse_formula(formula)
    missing = [v for v in variables if v not in coldata.columns]
    if missing:
        raise KeyError(f"variables not in coldata: {missing}")

    n = len(coldata)
    blocks: list[np.ndarray] = []
    columns: list[str] = []
    assign: list[str] = []
    levels: dict[str, list[str]] = {}

    if intercept:
        blocks.append(np.ones((n, 1)))
        columns.append("(Intercept)")
        assign.append("(Intercept)")

    for v in variables:
        s = coldata[v]
        if _is_categorical(s):
            cat = s.astype("category")
            if drop_unused_levels:
                cat = cat.cat.remove_unused_categories()
            levs = list(cat.cat.categories.astype(str))
            if len(levs) < 2:
                raise ValueError(f"variable {v!r} has fewer than 2 levels; drop it")
            codes = cat.cat.codes.to_numpy()
            if (codes < 0).any():
                raise ValueError(f"variable {v!r} has missing values")
            k = len(levs)
            block = np.zeros((n, k - 1))
            for i in range(k - 1):
                block[codes == i, i] = 1.0
            block[codes == k - 1, :] = -1.0
            blocks.append(block)
            # R names contr.sum columns <var>1 ... <var>{k-1}
            columns.extend(f"{v}{i + 1}" for i in range(k - 1))
            assign.extend([v] * (k - 1))
            levels[v] = levs
        else:
            x = pd.to_numeric(s, errors="raise").to_numpy(dtype=float)
            if not np.isfinite(x).all():
                raise ValueError(f"variable {v!r} has non-finite values")
            if center_numeric:
                x = x - x.mean()
            blocks.append(x.reshape(-1, 1))
            columns.append(v)
            assign.append(v)

    X = np.hstack(blocks) if blocks else np.zeros((n, 0))
    return DesignMatrix(X=X, columns=columns, assign=assign, levels=levels,
                        index=coldata.index)
