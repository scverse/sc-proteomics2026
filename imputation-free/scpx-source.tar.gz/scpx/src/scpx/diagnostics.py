"""Checks that decide whether a latent space is biology or acquisition depth.

These are the cheapest useful things you can run and they are routinely skipped.
On a real single-cell DIA matrix the leading component of both scplainer and
omicsGMF can correlate with per-cell detection depth at |r| > 0.8, which means
the headline figure is showing how much was detected per cell.
"""

from __future__ import annotations

import numpy as np
import pandas as pd
from scipy import stats

__all__ = [
    "detection_depth",
    "component_confounding",
    "detection_rate_by_group",
    "compare_embeddings",
    "differential_inflation",
]


def detection_depth(Y: pd.DataFrame) -> pd.Series:
    """Number of features observed per sample."""
    return Y.notna().sum(axis=0).rename("depth")


def component_confounding(
    scores: pd.DataFrame,
    depth: pd.Series,
    extra: pd.DataFrame | None = None,
    log_depth: bool = True,
) -> pd.DataFrame:
    """Correlate every component with detection depth and any other covariate.

    Returns one row per component with Pearson r against ``log2(depth)`` and
    against each numeric column of ``extra``. Anything above about |r| = 0.4 on
    a leading component means that component is carrying that covariate.
    """
    d = depth.reindex(scores.index).astype(float)
    x = np.log2(d.replace(0, np.nan)) if log_depth else d
    rows = []
    for comp in scores.columns:
        s = scores[comp].astype(float)
        ok = np.isfinite(s) & np.isfinite(x)
        row = {"component": comp,
               "r_depth": float(np.corrcoef(s[ok], x[ok])[0, 1]) if ok.sum() > 2 else np.nan}
        if extra is not None:
            for c in extra.columns:
                v = pd.to_numeric(extra[c].reindex(scores.index), errors="coerce")
                m = ok & np.isfinite(v)
                row[f"r_{c}"] = (float(np.corrcoef(s[m], v[m])[0, 1])
                                 if m.sum() > 2 else np.nan)
        rows.append(row)
    return pd.DataFrame(rows).set_index("component")


def detection_rate_by_group(Y: pd.DataFrame, groups: pd.Series) -> pd.DataFrame:
    """Per-feature detection rate in each group, plus the difference.

    A feature whose fold change tracks its detection-rate difference is telling
    you about detection, not abundance. Report this next to every hit.
    """
    g = groups.reindex(Y.columns)
    levels = list(pd.unique(g.dropna()))
    obs = Y.notna()
    out = pd.DataFrame(index=Y.index)
    for lv in levels:
        cols = g.index[g == lv]
        out[f"detection_{lv}"] = obs[cols].mean(axis=1)
    if len(levels) == 2:
        out["detection_diff"] = out[f"detection_{levels[0]}"] - out[f"detection_{levels[1]}"]
    return out


def compare_embeddings(A: pd.DataFrame, B: pd.DataFrame, k: int | None = None):
    """Canonical correlations between two sample embeddings.

    If these all come back near 1 the two methods found the same subspace and
    whatever comparison you set out to make has no contrast in it.
    """
    k = k or min(A.shape[1], B.shape[1])
    idx = A.index.intersection(B.index)
    a = A.loc[idx].to_numpy(dtype=float)[:, :k]
    b = B.loc[idx].to_numpy(dtype=float)[:, :k]
    a = (a - a.mean(0)) / np.where(a.std(0) > 0, a.std(0), 1)
    b = (b - b.mean(0)) / np.where(b.std(0) > 0, b.std(0), 1)
    Qa, _ = np.linalg.qr(a)
    Qb, _ = np.linalg.qr(b)
    return np.linalg.svd(Qa.T @ Qb, compute_uv=False)


def differential_inflation(
    Y: pd.DataFrame,
    completed: dict[str, pd.DataFrame],
    groups: pd.Series,
    alpha: float = 0.05,
) -> pd.DataFrame:
    """How many extra hits a completed matrix buys you over observed values only.

    Runs the same Welch t-test on the observed values and on each completed
    matrix. Effect sizes barely move; what moves is the within-group variance,
    because filled values sit on the model's low-rank surface. The extra hits
    are for entries that were never measured.
    """
    from .scplainer import benjamini_hochberg

    g = groups.reindex(Y.columns)
    levels = list(pd.unique(g.dropna()))
    if len(levels) != 2:
        raise ValueError(f"need exactly two groups, got {levels}")
    m1 = (g == levels[0]).to_numpy()
    m2 = (g == levels[1]).to_numpy()

    def run(M: np.ndarray, drop_na: bool) -> tuple[np.ndarray, np.ndarray]:
        lfc = np.full(M.shape[0], np.nan)
        pv = np.full(M.shape[0], np.nan)
        for i in range(M.shape[0]):
            a, b = M[i, m1], M[i, m2]
            if drop_na:
                a, b = a[np.isfinite(a)], b[np.isfinite(b)]
            if a.size >= 3 and b.size >= 3:
                lfc[i] = a.mean() - b.mean()
                pv[i] = stats.ttest_ind(a, b, equal_var=False).pvalue
        return lfc, pv

    rows = []
    lfc0, p0 = run(Y.to_numpy(dtype=float), True)
    base = int(np.nansum(benjamini_hochberg(p0) < alpha))
    rows.append({"matrix": "observed", "n_significant": base, "inflation_pct": 0.0,
                 "lfc_corr_vs_observed": 1.0})
    for name, C in completed.items():
        lfc, p = run(C.reindex(Y.index).to_numpy(dtype=float), False)
        n = int(np.nansum(benjamini_hochberg(p) < alpha))
        ok = np.isfinite(lfc0) & np.isfinite(lfc)
        rows.append({
            "matrix": name, "n_significant": n,
            "inflation_pct": 100 * (n - base) / base if base else np.nan,
            "lfc_corr_vs_observed": float(np.corrcoef(lfc0[ok], lfc[ok])[0, 1]),
        })
    return pd.DataFrame(rows)
