"""omicsGMF: generalized matrix factorization for omics data with missing values.

Port of the Gaussian case of ``omicsGMF`` (Segers et al., *Nature
Communications* 2026), which wraps the ``sgdGMF`` framework. The model is

.. math::  \\mu = X B^T + \\Gamma Z^T + U V^T

with, following the sgdGMF convention and matching omicsGMF's defaults:

* ``X`` ``(n_samples, p)`` known **sample**-level covariates, default a column of
  ones, so ``X B'`` supplies one intercept per feature;
* ``Z`` ``(n_features, q)`` known **feature**-level covariates, default a column
  of ones, so ``\\Gamma Z'`` supplies one intercept per sample. That second
  intercept is the model's own normalisation term and it is on by default;
* ``U`` ``(n_samples, d)`` latent factors and ``V`` ``(n_features, d)`` loadings.

Fitting differs from the package in one respect that is worth stating plainly:
omicsGMF optimises with block-stochastic gradient descent (that is what makes it
fast on large matrices), while this implementation uses alternating least squares
with the same EM/soft-impute treatment of missing entries the paper describes -
each iteration replaces unobserved positions with the current model prediction
rather than with any external heuristic. Same model, same likelihood, same
missing-value handling, different optimiser. On matrices of a few thousand by a
few hundred the two converge to the same fit; on very large matrices the SGD
version is the one you want.

Only the Gaussian family is implemented. That is the proteomics case (log-scale
intensities). Poisson and negative-binomial, which omicsGMF supports for RNA-seq,
are not here and the class will refuse anything else rather than pretend.
"""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np
import pandas as pd

__all__ = ["GMF", "GMFFit", "CVResult"]


@dataclass
class GMFFit:
    U: np.ndarray               # samples x d, orthogonalised
    V: np.ndarray               # features x d
    B: np.ndarray               # features x p   (sample-covariate coefficients)
    Gamma: np.ndarray           # samples x q    (feature-covariate coefficients)
    mu: np.ndarray              # samples x features, full reconstruction
    d: int
    n_iter: int
    converged: bool
    rel_change: float           # last relative change in deviance
    deviance: float             # residual SS on observed entries
    proportion_variance: np.ndarray


@dataclass
class CVResult:
    ranks: np.ndarray
    scores: np.ndarray          # n_folds x n_ranks, held-out MSE
    hold_frac: float
    n_folds: int

    @property
    def mean(self) -> np.ndarray:
        return self.scores.mean(axis=0)

    @property
    def sd(self) -> np.ndarray:
        return self.scores.std(axis=0)

    @property
    def best_rank(self) -> int:
        return int(self.ranks[int(np.argmin(self.mean))])

    def to_frame(self) -> pd.DataFrame:
        return pd.DataFrame({
            "rank": self.ranks, "mean_mse": self.mean, "sd_mse": self.sd,
        })


def _ls(A: np.ndarray, B: np.ndarray, ridge: float) -> np.ndarray:
    """Ridge least squares: argmin_W ||A W - B||^2 + ridge ||W||^2."""
    p = A.shape[1]
    return np.linalg.solve(A.T @ A + ridge * np.eye(p), A.T @ B)


class GMF:
    """Gaussian generalized matrix factorization with missing values.

    Parameters
    ----------
    Y
        ``(n_features, n_samples)`` matrix, features in rows, to match scp and
        the CSV layout people actually have. It is transposed internally to the
        ``(samples, features)`` orientation the model equation uses.
    X
        Sample-level covariates, ``(n_samples, p)``. ``None`` means a single
        intercept column, which is omicsGMF's default. Pass a design matrix here
        to correct for batch inside the factorization rather than after it.
    Z
        Feature-level covariates, ``(n_features, q)``. ``None`` means a single
        intercept column.
    add_intercept
        Prepend a column of ones to a user-supplied ``X`` / ``Z``. Default True.
    """

    def __init__(
        self,
        Y: pd.DataFrame | np.ndarray,
        X: np.ndarray | pd.DataFrame | None = None,
        Z: np.ndarray | pd.DataFrame | None = None,
        add_intercept: bool = True,
        ridge: float = 1e-8,
    ):
        if isinstance(Y, pd.DataFrame):
            self.features = list(Y.index.astype(str))
            self.samples = list(Y.columns.astype(str))
            M = Y.to_numpy(dtype=float)
        else:
            M = np.asarray(Y, dtype=float)
            self.features = [f"feature{i + 1}" for i in range(M.shape[0])]
            self.samples = [f"sample{i + 1}" for i in range(M.shape[1])]

        self.Y = M.T                                  # samples x features
        self.mask = np.isfinite(self.Y)
        if not self.mask.any(axis=0).all() or not self.mask.any(axis=1).all():
            raise ValueError(
                "a feature or a sample has no observed values; drop it first "
                "(omicsGMF raises the same error)"
            )

        n, m = self.Y.shape
        self.X = self._covariates(X, n, add_intercept, "X")
        self.Z = self._covariates(Z, m, add_intercept, "Z")
        self.ridge = float(ridge)
        self.fit_: GMFFit | None = None

    @staticmethod
    def _covariates(C, n_rows: int, add_intercept: bool, what: str) -> np.ndarray:
        if C is None:
            return np.ones((n_rows, 1))
        A = C.to_numpy(dtype=float) if isinstance(C, pd.DataFrame) else np.asarray(C, float)
        if A.ndim == 1:
            A = A[:, None]
        if A.shape[0] != n_rows:
            raise ValueError(f"{what} has {A.shape[0]} rows, expected {n_rows}")
        if add_intercept and not np.allclose(A[:, 0], 1.0):
            A = np.hstack([np.ones((n_rows, 1)), A])
        return A

    # ---------------------------------------------------------------- fitting
    def _fit_core(self, Y, mask, d, max_iter, tol, verbose=False):
        X, Z = self.X, self.Z
        n, m = Y.shape
        Yf = Y.copy()
        col_mean = np.nanmean(Y, axis=0)
        col_mean = np.where(np.isfinite(col_mean), col_mean, np.nanmean(Y))
        Yf[~mask] = np.broadcast_to(col_mean, Y.shape)[~mask]

        B = np.zeros((m, X.shape[1]))
        Gamma = np.zeros((n, Z.shape[1]))
        U = np.zeros((n, d))
        V = np.zeros((m, d))

        prev, converged, it, rel = np.inf, False, 0, np.inf
        for it in range(1, max_iter + 1):
            # sample-level covariates: solve X W = residual, W is p x m
            R = Yf - Gamma @ Z.T - U @ V.T
            B = _ls(X, R, self.ridge).T                      # m x p
            # feature-level covariates: solve Z W = residual', W is q x n
            R = Yf - X @ B.T - U @ V.T
            Gamma = _ls(Z, R.T, self.ridge).T                # n x q
            # latent structure: truncated SVD of what is left
            R = Yf - X @ B.T - Gamma @ Z.T
            if d > 0:
                Uu, s, Vt = np.linalg.svd(R, full_matrices=False)
                U = Uu[:, :d] * s[:d]
                V = Vt[:d].T
            mu = X @ B.T + Gamma @ Z.T + U @ V.T
            Yf = np.where(mask, Y, mu)

            dev = float(np.sum((Y[mask] - mu[mask]) ** 2))
            if verbose:
                print(f"  iter {it:3d}  deviance {dev:.6f}")
            rel = abs(prev - dev) / max(dev, 1e-12)
            if rel < tol:
                converged = True
                prev = dev
                break
            prev = dev

        # orthogonalise U so factors read like principal components, as the
        # paper does after convergence
        if d > 0:
            Uc = U - U.mean(axis=0)
            Ug, sg, Vgt = np.linalg.svd(Uc, full_matrices=False)
            U_out = Ug * sg
            V_out = V @ Vgt.T
            pv = sg**2 / np.sum(sg**2) if np.sum(sg**2) > 0 else np.zeros(d)
        else:
            U_out, V_out, pv = U, V, np.zeros(0)

        return GMFFit(U=U_out, V=V_out, B=B, Gamma=Gamma, mu=mu, d=d,
                      n_iter=it, converged=converged, rel_change=float(rel),
                      deviance=prev, proportion_variance=pv)

    def fit(self, d: int, max_iter: int = 400, tol: float = 1e-7,
            verbose: bool = False) -> GMFFit:
        """Fit at a fixed latent dimension."""
        if d < 0:
            raise ValueError("d must be >= 0")
        self.fit_ = self._fit_core(self.Y, self.mask, d, max_iter, tol, verbose)
        return self.fit_

    # --------------------------------------------------------------------- CV
    def cross_validate(
        self,
        ranks,
        n_folds: int = 3,
        hold_frac: float = 0.30,
        max_iter: int = 80,
        tol: float = 1e-6,
        seed: int = 0,
        verbose: bool = True,
    ) -> CVResult:
        """Choose the latent dimension by masking observed entries.

        Mirrors omicsGMF's cross-validation: each fold hides ``hold_frac`` of the
        **observed** entries, refits, and scores squared error on the hidden
        ones. The rank minimising mean held-out error is ``result.best_rank``.

        A caveat that applies to every method in this family: because you can
        only hide entries that were observed, this scores the MAR component
        only. It says nothing about how well the model predicts values that were
        missing because they fell below detection.
        """
        ranks = np.asarray(list(ranks), dtype=int)
        rng = np.random.default_rng(seed)
        obs = np.argwhere(self.mask)
        scores = np.zeros((n_folds, ranks.size))
        n_hold = int(hold_frac * len(obs))

        for f in range(n_folds):
            sel = rng.choice(len(obs), size=n_hold, replace=False)
            hold = obs[sel]
            train = self.mask.copy()
            train[hold[:, 0], hold[:, 1]] = False
            if not train.any(axis=0).all() or not train.any(axis=1).all():
                raise ValueError(
                    "a fold emptied a row or column; lower hold_frac or filter "
                    "sparser features first"
                )
            Ytr = np.where(train, self.Y, np.nan)
            for k, d in enumerate(ranks):
                fit = self._fit_core(Ytr, train, int(d), max_iter, tol)
                err = self.Y[hold[:, 0], hold[:, 1]] - fit.mu[hold[:, 0], hold[:, 1]]
                scores[f, k] = float(np.mean(err**2))
            if verbose:
                print(f"  fold {f + 1}/{n_folds} done", flush=True)
        return CVResult(ranks=ranks, scores=scores, hold_frac=hold_frac,
                        n_folds=n_folds)

    def fit_cv(self, ranks, **kw) -> tuple[GMFFit, CVResult]:
        """Cross-validate the rank, then refit at the winner."""
        cv_kw = {k: v for k, v in kw.items()
                 if k in {"n_folds", "hold_frac", "max_iter", "tol", "seed", "verbose"}}
        cv = self.cross_validate(ranks, **cv_kw)
        return self.fit(cv.best_rank), cv

    # ------------------------------------------------------------- accessors
    def _check(self) -> GMFFit:
        if self.fit_ is None:
            raise RuntimeError("call fit() or fit_cv() first")
        return self.fit_

    def factors(self) -> pd.DataFrame:
        """Sample scores, ``(n_samples, d)``. The analogue of ``reducedDim()``."""
        fit = self._check()
        return pd.DataFrame(
            fit.U, index=self.samples,
            columns=[f"Factor{i + 1}" for i in range(fit.d)],
        )

    def loadings(self) -> pd.DataFrame:
        fit = self._check()
        return pd.DataFrame(
            fit.V, index=self.features,
            columns=[f"Factor{i + 1}" for i in range(fit.d)],
        )

    def impute(self, only_missing: bool = True) -> pd.DataFrame:
        """Model-based completion, features x samples. ``imputeGMF()``.

        ``only_missing=True`` keeps every observed value untouched and fills only
        the gaps, which is what the R function does.

        Use this for visualisation. Do not feed it to a differential test: on a
        real SCP matrix the filled values sit on the model's low-rank surface,
        within-group variance collapses, and the hit count inflates by tens of
        percent for entries that were never measured.
        """
        fit = self._check()
        out = np.where(self.mask, self.Y, fit.mu) if only_missing else fit.mu
        return pd.DataFrame(out.T, index=self.features, columns=self.samples)

    def reconstruction(self) -> pd.DataFrame:
        """The full model prediction ``mu``, features x samples."""
        return pd.DataFrame(self._check().mu.T, index=self.features, columns=self.samples)

    def residuals(self) -> pd.DataFrame:
        """Observed minus fitted, NaN where unobserved."""
        fit = self._check()
        R = np.where(self.mask, self.Y - fit.mu, np.nan)
        return pd.DataFrame(R.T, index=self.features, columns=self.samples)

    def __repr__(self) -> str:
        d = self.fit_.d if self.fit_ else None
        return (
            f"GMF({len(self.features)} features x {len(self.samples)} samples, "
            f"{100 * (1 - self.mask.mean()):.1f}% missing, "
            f"X:{self.X.shape[1]} Z:{self.Z.shape[1]}, d={d})"
        )
