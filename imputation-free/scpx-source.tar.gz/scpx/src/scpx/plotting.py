"""Plot helpers, on a colourblind-validated palette.

The categorical slots are used in fixed order and never cycled. The first two
clear every all-pairs gate (worst CVD dE 24.7, normal-vision dE 33.6); past
three slots, encode the extra grouping with marker shape rather than a fourth
hue.
"""

from __future__ import annotations

import numpy as np
import pandas as pd

__all__ = ["PALETTE", "sequential_cmap", "diverging_cmap", "apply_style",
           "plot_cv", "plot_scores", "plot_variance", "plot_volcano"]

SURFACE = "#fcfcfb"
INK, INK2, INK3, GRID = "#0b0b0b", "#52514e", "#8a8983", "#e4e3df"
PALETTE = ["#2a78d6", "#eb6834", "#1baf7a", "#eda100",
           "#e87ba4", "#008300", "#4a3aa7", "#e34948"]
_SEQ_STEPS = ["#cde2fb", "#9ec5f4", "#6da7ec", "#3987e5",
              "#256abf", "#184f95", "#0d366b"]
_DIV_STEPS = [(0.00, "#184f95"), (0.25, "#6da7ec"), (0.50, "#f0efec"),
              (0.75, "#ef9291"), (1.00, "#a81f1e")]
MARKERS = ["o", "s", "^", "D", "v", "P", "X", "*"]


def _mpl():
    import matplotlib
    matplotlib.use("Agg", force=False)
    import matplotlib.pyplot as plt
    return plt


def _cmaps():
    from matplotlib.colors import LinearSegmentedColormap
    return (LinearSegmentedColormap.from_list("scpx_seq", _SEQ_STEPS),
            LinearSegmentedColormap.from_list("scpx_div", _DIV_STEPS))


def sequential_cmap():
    """One-hue light-to-dark ramp for continuous magnitude."""
    return _cmaps()[0]


def diverging_cmap():
    """Two-pole ramp with a neutral grey midpoint, for signed values."""
    return _cmaps()[1]


def apply_style() -> None:
    """Set matplotlib rcParams to the house style. Call once."""
    plt = _mpl()
    plt.rcParams.update({
        "figure.facecolor": SURFACE, "axes.facecolor": SURFACE,
        "savefig.facecolor": SURFACE, "font.size": 8, "axes.labelsize": 8,
        "axes.titlesize": 9, "axes.titleweight": "bold", "axes.labelcolor": INK2,
        "text.color": INK, "xtick.color": INK3, "ytick.color": INK3,
        "xtick.labelsize": 7, "ytick.labelsize": 7, "axes.edgecolor": GRID,
        "axes.linewidth": 0.8, "grid.color": GRID, "grid.linewidth": 0.6,
        "legend.frameon": False, "legend.fontsize": 7,
        "axes.spines.top": False, "axes.spines.right": False,
    })


def _finish(ax, title=None, xl=None, yl=None):
    if title:
        ax.set_title(title, loc="left", pad=6)
    if xl:
        ax.set_xlabel(xl)
    if yl:
        ax.set_ylabel(yl)
    ax.grid(True, alpha=0.7, zorder=0)
    ax.set_axisbelow(True)
    return ax


def plot_cv(cv, ax=None):
    """Held-out MSE against latent dimension, with the selected rank marked."""
    plt = _mpl()
    ax = ax or plt.subplots(figsize=(4, 3.2))[1]
    m, s = cv.mean, cv.sd
    ax.fill_between(cv.ranks, m - s, m + s, color=PALETTE[0], alpha=0.15, zorder=2)
    ax.plot(cv.ranks, m, color=PALETTE[0], lw=2, zorder=3)
    ax.scatter([cv.best_rank], [m.min()], s=60, facecolor=SURFACE,
               edgecolor=PALETTE[0], lw=2, zorder=4)
    ax.annotate(f"d = {cv.best_rank}", (cv.best_rank, m.min()),
                textcoords="offset points", xytext=(8, 8),
                fontweight="bold", color=PALETTE[0])
    return _finish(ax, "Rank by cross-validation", "latent dimension d",
                   f"held-out MSE ({cv.hold_frac:.0%} masked)")


def plot_scores(scores, colour=None, shape=None, ax=None, comps=(0, 1),
                title=None, continuous=None, cbar_label=""):
    """Scatter of two components, coloured by a factor or a continuous value."""
    plt = _mpl()
    ax = ax or plt.subplots(figsize=(4.2, 3.6))[1]
    x = scores.iloc[:, comps[0]].to_numpy()
    y = scores.iloc[:, comps[1]].to_numpy()

    if continuous is not None:
        v = pd.Series(continuous).reindex(scores.index).astype(float).to_numpy()
        sc = ax.scatter(x, y, s=26, c=v, cmap=_cmaps()[0], edgecolors=SURFACE,
                        linewidths=0.8, zorder=3)
        cb = plt.colorbar(sc, ax=ax, pad=0.02, fraction=0.045)
        cb.set_label(cbar_label, size=7, color=INK2)
        cb.ax.tick_params(labelsize=6, color=INK3, labelcolor=INK3)
        cb.outline.set_visible(False)
    else:
        col = (pd.Series(colour).reindex(scores.index).astype(str)
               if colour is not None else pd.Series("all", index=scores.index))
        shp = (pd.Series(shape).reindex(scores.index).astype(str)
               if shape is not None else None)
        cl = list(pd.unique(col))
        sl = list(pd.unique(shp)) if shp is not None else [None]
        for ci, c in enumerate(cl):
            for si, s in enumerate(sl):
                m = (col == c).to_numpy()
                if s is not None:
                    m &= (shp == s).to_numpy()
                if not m.any():
                    continue
                lab = c if s is None else f"{c} · {s}"
                ax.scatter(x[m], y[m], s=26, marker=MARKERS[si % len(MARKERS)],
                           c=PALETTE[ci % len(PALETTE)], edgecolors=SURFACE,
                           linewidths=0.8, zorder=3, label=lab)
        if colour is not None or shape is not None:
            ax.legend(frameon=True, facecolor=SURFACE, edgecolor="none",
                      framealpha=0.92, loc="best")
    return _finish(ax, title, scores.columns[comps[0]], scores.columns[comps[1]])


def plot_variance(variance: pd.DataFrame, ax=None, top: int | None = None):
    """Median percent explained variance per model term, across features."""
    plt = _mpl()
    ax = ax or plt.subplots(figsize=(4, 3.2))[1]
    med = (variance.groupby("effect")["percent_explained_var"]
           .median().sort_values(ascending=False))
    if top:
        med = med.head(top)
    cols = [PALETTE[i % len(PALETTE)] if e != "Residuals" else INK3
            for i, e in enumerate(med.index)]
    ax.bar(range(len(med)), med.to_numpy(), color=cols, width=0.62, zorder=3)
    ax.set_xticks(range(len(med)))
    ax.set_xticklabels(med.index, rotation=30, ha="right")
    for i, v in enumerate(med.to_numpy()):
        ax.text(i, v + 0.6, f"{v:.0f}", ha="center", fontsize=6.5, color=INK2)
    return _finish(ax, "Variance by model term", None, "median % explained")


def plot_volcano(da: pd.DataFrame, ax=None, alpha=0.05, title=None,
                 colour=PALETTE[0], label_top: int = 0):
    """Volcano from a ``differential_analysis()`` table."""
    plt = _mpl()
    ax = ax or plt.subplots(figsize=(4.2, 3.6))[1]
    est = da["estimate"].to_numpy(dtype=float)
    padj = da["padj"].to_numpy(dtype=float)
    ok = np.isfinite(est) & np.isfinite(padj)
    nl = -np.log10(np.clip(padj[ok], 1e-300, 1))
    sig = padj[ok] < alpha
    ax.scatter(est[ok][~sig], nl[~sig], s=5, c=INK3, alpha=0.35, lw=0, zorder=3)
    ax.scatter(est[ok][sig], nl[sig], s=6, c=colour, alpha=0.8, lw=0, zorder=4)
    ax.axhline(-np.log10(alpha), color=INK2, lw=0.8, ls="--", zorder=2)
    ax.text(0.03, 0.95, f"{int(sig.sum())} at FDR {alpha:.0%}",
            transform=ax.transAxes, va="top", fontsize=7.5,
            fontweight="bold", color=colour)
    if label_top:
        sub = da[ok].nsmallest(label_top, "padj")
        for _, r in sub.iterrows():
            ax.annotate(str(r["feature"]),
                        (r["estimate"], -np.log10(max(r["padj"], 1e-300))),
                        fontsize=6, color=INK2,
                        textcoords="offset points", xytext=(3, 3))
    return _finish(ax, title or (da.attrs.get("contrast") or "Differential"),
                   "estimate (log2 FC)", "−log10 FDR")
