"""scplainer: per-feature linear modelling of single-cell proteomics data.

Port of the modelling core of the Bioconductor package ``scp`` (Vanderaa &
Gatto, *Genome Biology* 2025). Formulas were taken from the R source rather than
the paper, so the numbers line up:

* ridge solve with ``lambda = 1e-3``: ``beta = (X'X + lambda I)^-1 X'y``
* ``df = max(n_observed - n_params, 1)``, ``var = RSS / df``
* ``uvcov = (X (X'X + lambda I)^-1)' (X (X'X + lambda I)^-1)``, ``Vcov = var * uvcov``
* factors are coded ``contr.sum`` (see :mod:`scpx.design`)
* effect matrix for a variable is ``X[:, cols] @ beta[cols]``
* variance denominator is ``SS_residual + sum(SS_effects)``, **not** ``SS_total``
* APCA runs PCA on ``effect + residuals``; ASCA on the effect alone
* differential testing is a t-test on ``c'beta`` with ``se = sqrt(c' Vcov c)``

Nothing is imputed anywhere. Each feature is fitted on the cells that observed
it, and missing values simply reduce that feature's n.

**Know what you are running.** With an intercept-only formula X is one column,
beta_j is the feature mean, the APCA effect matrix ``X beta' + E`` is the
observed data itself, and the component analysis degenerates to NIPALS PCA on
centred data. The variance partitioning and batch handling that motivate
scplainer only exist once the design has covariates in it.
"""

from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np
import pandas as pd
from scipy import stats

from .decomposition import PCAResult, auto_pca, nipals, svd_pca
from .design import DesignMatrix, build_design

__all__ = ["FeatureFit", "ScpModel", "benjamini_hochberg"]

RIDGE_LAMBDA = 1e-3


def benjamini_hochberg(p: np.ndarray) -> np.ndarray:
    """BH FDR, NaN-safe. Matches ``p.adjust(method = "BH")``."""
    p = np.asarray(p, dtype=float)
    out = np.full(p.shape, np.nan)
    ok = np.isfinite(p)
    pv = p[ok]
    n = pv.size
    if n == 0:
        return out
    order = np.argsort(pv)
    adj = np.minimum.accumulate((pv[order] * n / np.arange(1, n + 1))[::-1])[::-1]
    res = np.empty(n)
    res[order] = np.clip(adj, 0, 1)
    out[ok] = res
    return out


@dataclass
class FeatureFit:
    """One feature's ridge fit on the cells that observed it."""

    feature: str
    sample_idx: np.ndarray            # positions of observed samples
    coefficients: np.ndarray          # n_params
    residuals: np.ndarray             # n_observed
    df: int
    var: float
    uvcov: np.ndarray                 # n_params x n_params
    n_obs: int
    n_params: int

    @property
    def vcov(self) -> np.ndarray:
        return self.var * self.uvcov

    @property
    def np_ratio(self) -> float:
        return self.n_obs / self.n_params if self.n_params else np.inf


def _fit_ridge(y: np.ndarray, X: np.ndarray, lam: float = RIDGE_LAMBDA):
    """``scp:::.fitRidge()``."""
    p = X.shape[1]
    xtx_inv = np.linalg.inv(X.T @ X + lam * np.eye(p))
    beta = xtx_inv @ (X.T @ y)
    resid = y - X @ beta
    df = max(len(y) - p, 1)
    A = X @ xtx_inv
    return beta, resid, df, float(resid @ resid) / df, A.T @ A


class ScpModel:
    """Fit and interrogate a scplainer model.

    Parameters
    ----------
    Y
        ``(n_features, n_samples)`` matrix of log-scale intensities with NaN for
        missing values. A ``DataFrame`` keeps feature and sample names.
    coldata
        Sample annotations, one row per column of ``Y``, in the same order.
    formula
        R-style, e.g. ``"~ 1 + MedianIntensity + run"``.
    np_threshold
        Minimum ``n_observed / n_params`` for a feature to be kept. scp's
        default is 1: below it the feature has fewer observations than
        parameters and cannot be fitted. Raising it is the principled
        replacement for an arbitrary completeness cutoff.
    drop_rank_deficient
        Skip features whose observed cells do not span the design. Default
        True. scp keeps them because the ridge term makes the normal equations
        solvable regardless, but the resulting contrast is not estimable from
        that feature's data. Set False for bit-compatibility with R.
    center_numeric
        Centre numeric covariates before fitting. Default True. See
        :func:`scpx.design.build_design` for why this differs from R and why it
        changes nothing except the intercept and the variance decomposition.
    """

    def __init__(
        self,
        Y: pd.DataFrame | np.ndarray,
        coldata: pd.DataFrame,
        formula: str = "~ 1",
        np_threshold: float = 1.0,
        ridge_lambda: float = RIDGE_LAMBDA,
        drop_rank_deficient: bool = True,
        center_numeric: bool = True,
    ):
        if isinstance(Y, pd.DataFrame):
            self.features = list(Y.index.astype(str))
            self.samples = list(Y.columns.astype(str))
            Ym = Y.to_numpy(dtype=float)
        else:
            Ym = np.asarray(Y, dtype=float)
            self.features = [f"feature{i + 1}" for i in range(Ym.shape[0])]
            self.samples = [f"sample{i + 1}" for i in range(Ym.shape[1])]
        if len(coldata) != Ym.shape[1]:
            raise ValueError(
                f"coldata has {len(coldata)} rows but Y has {Ym.shape[1]} columns"
            )

        self.Y = Ym
        self.coldata = coldata.copy()
        self.coldata.index = pd.Index(self.samples)
        self.formula = formula
        self.np_threshold = float(np_threshold)
        self.ridge_lambda = float(ridge_lambda)
        self.drop_rank_deficient = bool(drop_rank_deficient)

        self.center_numeric = bool(center_numeric)
        self.design: DesignMatrix = build_design(
            self.coldata, formula, center_numeric=self.center_numeric
        )
        self.fits: dict[str, FeatureFit] = {}
        self._fit()

    # ---------------------------------------------------------------- fitting
    def _fit(self) -> None:
        X = self.design.X
        p = X.shape[1]
        obs = np.isfinite(self.Y)
        for i, name in enumerate(self.features):
            idx = np.flatnonzero(obs[i])
            if idx.size < p or p == 0:
                continue          # scp:::.fitModel returns an empty fit here
            Xi = X[idx]
            if self.drop_rank_deficient and np.linalg.matrix_rank(Xi) < p:
                # Deliberate deviation from scp. There, the 1e-3 ridge makes
                # X'X + lambda*I invertible even when the observed cells do not
                # span the design, so R returns a fit whose coefficients are
                # driven by the penalty rather than the data, and n/p can still
                # clear the threshold. Those contrasts are not estimable. Set
                # drop_rank_deficient=False to reproduce R's behaviour exactly.
                continue
            beta, resid, df, var, uvcov = _fit_ridge(
                self.Y[i, idx], Xi, self.ridge_lambda
            )
            self.fits[name] = FeatureFit(
                feature=name, sample_idx=idx, coefficients=beta, residuals=resid,
                df=df, var=var, uvcov=uvcov, n_obs=idx.size, n_params=p,
            )

    # ------------------------------------------------------------- accessors
    @property
    def kept_features(self) -> list[str]:
        """Features that fitted and pass the n/p threshold."""
        return [f for f, fit in self.fits.items() if fit.np_ratio >= self.np_threshold]

    def np_ratios(self) -> pd.Series:
        return pd.Series(
            {f: fit.np_ratio for f, fit in self.fits.items()}, name="np_ratio"
        ).reindex(self.features)

    def coefficients(self, filtered: bool = True) -> pd.DataFrame:
        feats = self.kept_features if filtered else list(self.fits)
        return pd.DataFrame(
            [self.fits[f].coefficients for f in feats],
            index=feats, columns=self.design.columns,
        )

    def intercepts(self, filtered: bool = True) -> pd.Series:
        if "(Intercept)" not in self.design.columns:
            return pd.Series(0.0, index=self.kept_features if filtered else list(self.fits))
        j = self.design.columns.index("(Intercept)")
        feats = self.kept_features if filtered else list(self.fits)
        return pd.Series([self.fits[f].coefficients[j] for f in feats], index=feats)

    def _feature_matrix(self, filtered: bool = True) -> tuple[list[str], np.ndarray]:
        feats = self.kept_features if filtered else list(self.fits)
        rows = [self.features.index(f) for f in feats]
        return feats, self.Y[rows]

    def input(self, filtered: bool = True) -> pd.DataFrame:
        """``scpModelInput()``: the observed data for the retained features."""
        feats, M = self._feature_matrix(filtered)
        return pd.DataFrame(M, index=feats, columns=self.samples)

    def residuals(self, filtered: bool = True) -> pd.DataFrame:
        """``scpModelResiduals()``: features x samples, NaN where unobserved."""
        feats = self.kept_features if filtered else list(self.fits)
        R = np.full((len(feats), len(self.samples)), np.nan)
        for r, f in enumerate(feats):
            fit = self.fits[f]
            R[r, fit.sample_idx] = fit.residuals
        return pd.DataFrame(R, index=feats, columns=self.samples)

    def effect(self, variable: str, filtered: bool = True) -> pd.DataFrame:
        """``scpModelEffects()[[variable]]``: ``X[:, cols] @ beta[cols]``."""
        cols = self.design.columns_for(variable)
        if cols.size == 0:
            raise KeyError(f"{variable!r} contributes no columns to the design")
        feats = self.kept_features if filtered else list(self.fits)
        E = np.full((len(feats), len(self.samples)), np.nan)
        Xc = self.design.X[:, cols]
        for r, f in enumerate(feats):
            fit = self.fits[f]
            E[r, fit.sample_idx] = Xc[fit.sample_idx] @ fit.coefficients[cols]
        return pd.DataFrame(E, index=feats, columns=self.samples)

    # ------------------------------------------------------ variance analysis
    def variance_analysis(self, use_total_ss: bool = False) -> pd.DataFrame:
        """Per-feature ANOVA-style decomposition. ``scpVarianceAnalysis()``.

        Returns long format with columns ``feature``, ``effect``, ``SS``, ``df``,
        ``percent_explained_var``. The default denominator is
        ``SS_residual + sum(SS_effects)`` (Thiel et al. 2017 eq. 26), which is
        what scp uses; ``use_total_ss=True`` switches to eq. 24.
        """
        feats = self.kept_features
        Yk = self.input().loc[feats].to_numpy()
        icpt = self.intercepts().reindex(feats).to_numpy()[:, None]
        ss_total = np.nansum((Yk - icpt) ** 2, axis=1)
        ss = {"Residuals": np.nansum(self.residuals().loc[feats].to_numpy() ** 2, axis=1)}
        for v in self.design.variables:
            ss[v] = np.nansum(self.effect(v).loc[feats].to_numpy() ** 2, axis=1)

        denom = ss_total if use_total_ss else np.sum(list(ss.values()), axis=0)
        denom = np.where(denom > 0, denom, np.nan)
        df = np.array([self.fits[f].df for f in feats], dtype=float)

        out = []
        for name, v in ss.items():
            out.append(pd.DataFrame({
                "feature": feats, "effect": name, "SS": v, "df": df,
                "percent_explained_var": v / denom * 100,
            }))
        return pd.concat(out, ignore_index=True)

    # ----------------------------------------------------- component analysis
    def component_analysis(
        self,
        ncomp: int = 2,
        method: str = "APCA",
        effects: list[str] | None = None,
        pca_fun: str = "auto",
        **kw,
    ) -> dict[str, PCAResult]:
        """``scpComponentAnalysis()``.

        Returns a dict keyed by ``"unmodelled"``, ``"residuals"`` and one entry
        per requested effect (named ``"APCA_<var>"`` etc.).

        ``method`` is one of ``"APCA"`` (PCA on effect + residuals, the scp
        default), ``"ASCA"`` (effect alone) or ``"ASCA.E"`` (fit on the effect,
        then project the augmented matrix onto those eigenvectors).
        """
        method = method.upper().replace("ASCA-E", "ASCA.E")
        if method not in {"APCA", "ASCA", "ASCA.E"}:
            raise ValueError("method must be APCA, ASCA or ASCA.E")
        fun = {"auto": auto_pca, "nipals": nipals, "svd": svd_pca}[pca_fun]

        feats = self.kept_features
        res: dict[str, PCAResult] = {
            "unmodelled": fun(self.input().loc[feats].to_numpy(), ncomp=ncomp, **kw),
            "residuals": fun(self.residuals().loc[feats].to_numpy(), ncomp=ncomp, **kw),
        }
        R = self.residuals().loc[feats].to_numpy()
        for v in (self.design.variables if effects is None else effects):
            M = self.effect(v).loc[feats].to_numpy()
            if method == "APCA":
                res[f"APCA_{v}"] = fun(M + R, ncomp=ncomp, **kw)
            elif method == "ASCA":
                res[f"ASCA_{v}"] = fun(M, ncomp=ncomp, **kw)
            else:
                r = fun(M, ncomp=ncomp, **kw)
                aug = np.nan_to_num(M + R, nan=0.0)
                r = PCAResult(
                    scores=aug.T @ r.eigenvectors,
                    eigenvectors=r.eigenvectors,
                    eigenvalues=np.full(ncomp, np.nan),
                    proportion_variance=np.full(ncomp, np.nan),
                    n_iter=r.n_iter, converged=r.converged,
                )
                res[f"ASCA.E_{v}"] = r
        return res

    def scores_frame(self, result: PCAResult) -> pd.DataFrame:
        """Sample scores as a DataFrame joined to ``coldata``."""
        df = pd.DataFrame(result.scores, index=self.samples, columns=result.names)
        return df.join(self.coldata)

    # -------------------------------------------------- differential analysis
    def differential_analysis(
        self,
        variable: str,
        level_a: str,
        level_b: str,
    ) -> pd.DataFrame:
        """t-test on the contrast ``level_a - level_b``. ``scpDifferentialAnalysis()``.

        Uses only the fitted coefficients, so no missing value is ever filled.
        Features whose fit could not be identified are absent from the output.
        """
        c = self.design.contrast(variable, level_a, level_b)
        return self._test_contrast(c, label=f"{variable}: {level_a} - {level_b}")

    def test_coefficient(self, column: str) -> pd.DataFrame:
        """t-test that a single design column's coefficient is zero."""
        if column not in self.design.columns:
            raise KeyError(f"{column!r} is not a design column: {self.design.columns}")
        c = np.zeros(self.design.n_params)
        c[self.design.columns.index(column)] = 1.0
        return self._test_contrast(c, label=column)

    def _test_contrast(self, c: np.ndarray, label: str) -> pd.DataFrame:
        feats = self.kept_features
        est = np.full(len(feats), np.nan)
        se = np.full(len(feats), np.nan)
        df = np.full(len(feats), np.nan)
        for i, f in enumerate(feats):
            fit = self.fits[f]
            est[i] = c @ fit.coefficients
            v = c @ fit.vcov @ c
            se[i] = np.sqrt(v) if v > 0 else np.nan
            df[i] = fit.df
        t = est / se
        p = 2 * stats.t.sf(np.abs(t), df)
        out = pd.DataFrame({
            "feature": feats, "estimate": est, "se": se, "df": df,
            "t": t, "pvalue": p, "padj": benjamini_hochberg(p),
            "n_obs": [self.fits[f].n_obs for f in feats],
        })
        out.attrs["contrast"] = label
        return out

    # --------------------------------------------------------------- utility
    def remove_batch_effect(self, keep: list[str] | None = None) -> pd.DataFrame:
        """``scpRemoveBatchEffect()``: intercept + kept effects + residuals.

        Everything not in ``keep`` is dropped from the reconstruction. With
        ``keep=None`` you get intercept + residuals, i.e. every modelled effect
        removed. This is a *visualisation* output. Do not feed it to a
        differential test: the values at unobserved positions are still NaN, but
        the observed ones have had modelled variation subtracted, and testing
        them again double-counts the model.
        """
        feats = self.kept_features
        out = self.residuals().loc[feats].to_numpy() + \
            self.intercepts().reindex(feats).to_numpy()[:, None]
        for v in (keep or []):
            out = out + np.nan_to_num(self.effect(v).loc[feats].to_numpy(), nan=0.0)
        M = self.input().loc[feats].to_numpy()
        out[~np.isfinite(M)] = np.nan
        return pd.DataFrame(out, index=feats, columns=self.samples)

    def __repr__(self) -> str:
        return (
            f"ScpModel(formula={self.formula!r}, "
            f"{len(self.features)} features, {len(self.samples)} samples, "
            f"{len(self.kept_features)} kept at n/p >= {self.np_threshold}, "
            f"params={self.design.columns})"
        )
