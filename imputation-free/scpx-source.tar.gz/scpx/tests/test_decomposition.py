import numpy as np
import pytest

from scpx.decomposition import auto_pca, nipals, svd_pca


def low_rank(n_feat=40, n_samp=25, rank=3, noise=0.05, seed=0):
    rng = np.random.default_rng(seed)
    U = rng.normal(size=(n_samp, rank))
    V = rng.normal(size=(n_feat, rank))
    return (U @ V.T).T + rng.normal(0, noise, (n_feat, n_samp)), U, V


def test_svd_pca_matches_numpy_pca():
    M, _, _ = low_rank()
    r = svd_pca(M, ncomp=4)
    A = M.T - M.T.mean(axis=0)
    _, d, _ = np.linalg.svd(A, full_matrices=False)
    assert np.allclose(r.proportion_variance, (d**2 / np.sum(d**2))[:4])
    # reconstruction from scores x loadings recovers the centred matrix
    approx = r.scores @ r.eigenvectors.T
    assert np.linalg.norm(approx - A) / np.linalg.norm(A) < 0.05


def test_nipals_matches_svd_on_complete_data():
    """With no missing values NIPALS must reproduce the SVD solution
    up to a per-component sign flip."""
    M, _, _ = low_rank(noise=0.02)
    a = svd_pca(M, ncomp=3)
    b = nipals(M, ncomp=3, tol=1e-12, max_iter=2000)
    for k in range(3):
        r = abs(np.corrcoef(a.scores[:, k], b.scores[:, k])[0, 1])
        assert r > 0.999, f"component {k} diverged, |r| = {r:.4f}"
    assert np.allclose(a.proportion_variance, b.proportion_variance, atol=1e-3)


def test_nipals_ignores_missing_and_recovers_structure():
    """15% missing at random should not stop NIPALS recovering the
    subspace found on the complete matrix."""
    M, _, _ = low_rank(noise=0.02, seed=3)
    rng = np.random.default_rng(1)
    Mm = M.copy()
    Mm[rng.random(M.shape) < 0.15] = np.nan
    full = svd_pca(M, ncomp=2)
    part = nipals(Mm, ncomp=2, tol=1e-10, max_iter=1000)
    for k in range(2):
        assert abs(np.corrcoef(full.scores[:, k], part.scores[:, k])[0, 1]) > 0.97


def test_nipals_never_imputes():
    """Changing the values sitting at masked positions must not change the
    fit at all. If it does, something is reading unobserved entries."""
    M, _, _ = low_rank(seed=7)
    rng = np.random.default_rng(2)
    mask = rng.random(M.shape) < 0.2
    A, B = M.copy(), M.copy()
    A[mask] = np.nan
    B[mask] = np.nan
    r1 = nipals(A, ncomp=2, tol=1e-10)
    r2 = nipals(B, ncomp=2, tol=1e-10)
    assert np.allclose(r1.scores, r2.scores)


def test_auto_pca_dispatch():
    M, _, _ = low_rank()
    assert auto_pca(M, ncomp=2).converged.all()          # svd path
    Mm = M.copy()
    Mm[0, 0] = np.nan
    auto_pca(Mm, ncomp=2)                                 # nipals path, no raise
    with pytest.raises(ValueError):
        svd_pca(Mm, ncomp=2)


def test_ncomp_bounds():
    M, _, _ = low_rank(n_feat=5, n_samp=4)
    with pytest.raises(ValueError):
        nipals(M, ncomp=5)
