import numpy as np
import pandas as pd
import pytest

from scpx.design import build_design, parse_formula


def coldata():
    return pd.DataFrame(
        {
            "batch": ["a", "a", "b", "b", "c", "c"],
            "depth": [1.0, 2.0, 3.0, 4.0, 5.0, 6.0],
        },
        index=[f"s{i}" for i in range(6)],
    )


def test_parse_formula_variants():
    assert parse_formula("~ 1") == (True, [])
    assert parse_formula("~ 1 + a + b") == (True, ["a", "b"])
    assert parse_formula("~ a + b") == (True, ["a", "b"])
    assert parse_formula("~ 0 + a") == (False, ["a"])
    assert parse_formula("~ a - 1") == (False, ["a"])
    with pytest.raises(ValueError):
        parse_formula("~ a + a")


def test_contr_sum_shape_and_zero_sum():
    """A k-level factor gives k-1 columns and each column sums to zero
    across the level set, which is what makes the effect matrices centred."""
    d = build_design(coldata(), "~ 1 + batch")
    assert d.columns == ["(Intercept)", "batch1", "batch2"]
    assert d.assign == ["(Intercept)", "batch", "batch"]
    assert d.levels["batch"] == ["a", "b", "c"]

    # one row per level, then column sums must be zero
    per_level = np.array([d.X[0, 1:], d.X[2, 1:], d.X[4, 1:]])
    assert np.allclose(per_level.sum(axis=0), 0.0)
    # last level is coded -1 everywhere
    assert np.allclose(d.X[4, 1:], [-1.0, -1.0])


def test_numeric_covariate_passed_through():
    raw = build_design(coldata(), "~ 1 + depth", center_numeric=False)
    assert raw.columns == ["(Intercept)", "depth"]
    assert np.allclose(raw.X[:, 1], coldata()["depth"].to_numpy())
    ctr = build_design(coldata(), "~ 1 + depth")          # centred by default
    assert np.allclose(ctr.X[:, 1], coldata()["depth"].to_numpy()
                       - coldata()["depth"].mean())
    assert ctr.X[:, 1].mean() == pytest.approx(0.0)


def test_contrast_vector_absorbed_level():
    """The contrast for the absorbed (last) level must use -1 coding, so
    a - c is (1,0) - (-1,-1) = (2,1)."""
    d = build_design(coldata(), "~ 1 + batch")
    c = d.contrast("batch", "a", "c")
    assert np.allclose(c, [0.0, 2.0, 1.0])
    c2 = d.contrast("batch", "a", "b")
    assert np.allclose(c2, [0.0, 1.0, -1.0])
    # antisymmetry
    assert np.allclose(d.contrast("batch", "b", "a"), -c2)


def test_contrast_recovers_group_difference():
    """c' beta must equal mean(a) - mean(b) for a balanced one-factor design."""
    cd = coldata()
    d = build_design(cd, "~ 1 + batch")
    rng = np.random.default_rng(0)
    true = {"a": 1.0, "b": 4.0, "c": -2.0}
    y = np.array([true[g] for g in cd["batch"]]) + rng.normal(0, 1e-9, len(cd))
    beta, *_ = np.linalg.lstsq(d.X, y, rcond=None)
    for x, z in [("a", "b"), ("a", "c"), ("b", "c")]:
        assert d.contrast("batch", x, z) @ beta == pytest.approx(true[x] - true[z], abs=1e-6)


def test_missing_variable_raises():
    with pytest.raises(KeyError):
        build_design(coldata(), "~ 1 + nope")


def test_centering_numeric_only_moves_the_intercept():
    """Under ordinary least squares, centring moves only the intercept."""
    cd = coldata()
    cd = cd.assign(depth=cd["depth"] + 20.0)          # the SCP-like scale
    d_raw = build_design(cd, "~ 1 + batch + depth", center_numeric=False)
    d_ctr = build_design(cd, "~ 1 + batch + depth", center_numeric=True)
    rng = np.random.default_rng(3)
    y = 20 + 0.7 * cd["depth"].to_numpy() + rng.normal(0, 0.1, len(cd))

    b_raw, *_ = np.linalg.lstsq(d_raw.X, y, rcond=None)
    b_ctr, *_ = np.linalg.lstsq(d_ctr.X, y, rcond=None)
    assert np.allclose(b_raw[1:], b_ctr[1:], atol=1e-8)      # slopes identical
    assert not np.isclose(b_raw[0], b_ctr[0])                # intercept moves
    assert np.allclose(d_raw.X @ b_raw, d_ctr.X @ b_ctr)     # same fit
    # and the contrast is unaffected
    assert np.allclose(d_raw.contrast("batch", "a", "b") @ b_raw,
                       d_ctr.contrast("batch", "a", "b") @ b_ctr)


def test_uncentred_covariate_is_ill_conditioned():
    """A covariate at the log2-intensity scale (~20) makes X'X nearly
    singular, so scplainer's 1e-3 ridge visibly perturbs the slope. Centring
    fixes the conditioning. This is why the default deviates from R."""
    cd = coldata().assign(depth=lambda d: d["depth"] + 20.0)
    raw = build_design(cd, "~ 1 + depth", center_numeric=False)
    ctr = build_design(cd, "~ 1 + depth", center_numeric=True)
    k_raw = np.linalg.cond(raw.X.T @ raw.X)
    k_ctr = np.linalg.cond(ctr.X.T @ ctr.X)
    assert k_raw > 100 * k_ctr, f"cond {k_raw:.3g} vs {k_ctr:.3g}"


def test_centering_fixes_the_variance_decomposition():
    """Uncentred, a covariate on the log2-intensity scale eats the whole
    decomposition. This is the trap the default guards against."""
    from scpx import ScpModel
    rng = np.random.default_rng(4)
    n, m = 40, 30
    med = rng.normal(20, 0.5, n)
    Y = pd.DataFrame(
        rng.normal(20, 2, m)[:, None] + 0.8 * med[None, :] + rng.normal(0, 0.3, (m, n)),
        index=[f"p{i}" for i in range(m)], columns=[f"c{i}" for i in range(n)])
    cd = pd.DataFrame({"MedianIntensity": med}, index=Y.columns)

    raw = ScpModel(Y, cd, "~ 1 + MedianIntensity", center_numeric=False)
    ctr = ScpModel(Y, cd, "~ 1 + MedianIntensity", center_numeric=True)
    f = lambda m_: (m_.variance_analysis()
                    .groupby("effect")["percent_explained_var"].median())
    assert f(raw)["MedianIntensity"] > 99      # "explains everything"
    assert f(ctr)["MedianIntensity"] < 90      # an actual partition

    # Residuals are NOT identical, and that is the point: with the covariate
    # uncentred the ridge is acting on a near-singular X'X, so it perturbs the
    # slope as well. Centring is a correction, not a presentation choice.
    diff = np.abs(raw.residuals().to_numpy() - ctr.residuals().to_numpy()).max()
    scale = np.abs(ctr.residuals().to_numpy()).mean()
    assert diff > 0.1 * scale
