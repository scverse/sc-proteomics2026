import numpy as np
import pandas as pd
import pytest

from scpx import GMF
from scpx.diagnostics import compare_embeddings


def synth(n_feat=120, n_samp=60, rank=3, noise=0.3, missing=0.2,
          batch_shift=0.0, seed=0):
    """Features x samples with known rank, optional per-feature batch offset."""
    rng = np.random.default_rng(seed)
    U = rng.normal(size=(n_samp, rank))
    V = rng.normal(size=(n_feat, rank))
    feat_mean = rng.normal(20, 2, n_feat)[:, None]
    samp_mean = rng.normal(0, 1, n_samp)[None, :]
    Y = feat_mean + samp_mean + (U @ V.T).T + rng.normal(0, noise, (n_feat, n_samp))

    batch = np.array(["b1"] * (n_samp // 2) + ["b2"] * (n_samp - n_samp // 2))
    if batch_shift:
        per_feature = rng.normal(0, batch_shift, n_feat)[:, None]
        Y = Y + per_feature * (batch == "b2")[None, :]

    mask = rng.random(Y.shape) < missing
    Ym = Y.copy()
    Ym[mask] = np.nan
    cols = [f"c{i}" for i in range(n_samp)]
    idx = [f"p{i}" for i in range(n_feat)]
    return (pd.DataFrame(Ym, index=idx, columns=cols),
            pd.DataFrame(Y, index=idx, columns=cols),
            pd.Series(batch, index=cols), mask, U)


def test_defaults_give_feature_and_sample_intercepts():
    Ym, *_ = synth()
    g = GMF(Ym)
    assert g.X.shape == (Ym.shape[1], 1)     # sample covariates -> feature intercepts
    assert g.Z.shape == (Ym.shape[0], 1)     # feature covariates -> sample intercepts
    fit = g.fit(d=0)                          # intercepts only, still a valid model
    assert fit.mu.shape == (Ym.shape[1], Ym.shape[0])


def test_all_missing_row_is_rejected():
    Ym, *_ = synth()
    Ym.iloc[0, :] = np.nan
    with pytest.raises(ValueError, match="no observed values"):
        GMF(Ym)


def test_recovers_latent_subspace():
    """Factors must span the same subspace as the simulated U."""
    Ym, _, _, _, U = synth(rank=3, noise=0.2, missing=0.15, seed=1)
    g = GMF(Ym)
    g.fit(d=3, max_iter=300)
    cc = compare_embeddings(g.factors(),
                            pd.DataFrame(U, index=g.samples,
                                         columns=["u1", "u2", "u3"]))
    assert cc.min() > 0.9, f"canonical correlations too low: {cc}"


def test_beats_mean_fill_on_held_out_entries():
    """The point of the model: predict masked entries better than the
    per-feature mean, which is what a naive fill would use."""
    Ym, Yfull, _, mask, _ = synth(rank=3, noise=0.25, missing=0.2, seed=2)
    g = GMF(Ym)
    g.fit(d=3, max_iter=300)
    pred = g.reconstruction().to_numpy()
    truth = Yfull.to_numpy()
    naive = np.tile(np.nanmean(Ym.to_numpy(), axis=1)[:, None], (1, Ym.shape[1]))
    mse_model = np.mean((truth[mask] - pred[mask]) ** 2)
    mse_naive = np.mean((truth[mask] - naive[mask]) ** 2)
    assert mse_model < 0.4 * mse_naive


def test_cross_validation_selects_near_true_rank():
    Ym, *_ = synth(rank=3, noise=0.35, missing=0.15, seed=3)
    g = GMF(Ym)
    cv = g.cross_validate([1, 2, 3, 4, 6, 10], n_folds=3, hold_frac=0.25,
                          max_iter=60, seed=0, verbose=False)
    assert cv.best_rank in (2, 3, 4), f"CV chose {cv.best_rank}"
    assert cv.to_frame().shape == (6, 3)
    # the curve must be U-shaped: overfitting at high rank
    assert cv.mean[-1] > cv.mean.min()


def test_sample_covariates_absorb_a_batch_effect():
    """With batch in X the factors should stop carrying it."""
    Ym, _, batch, _, _ = synth(rank=2, noise=0.2, missing=0.15,
                               batch_shift=2.5, seed=4)
    b = (batch == "b2").astype(float).to_numpy()[:, None]

    naive = GMF(Ym)
    naive.fit(d=3, max_iter=300)
    r_naive = max(
        abs(np.corrcoef(naive.factors().iloc[:, k], b[:, 0])[0, 1]) for k in range(3)
    )

    corrected = GMF(Ym, X=b)
    corrected.fit(d=3, max_iter=300)
    r_corr = max(
        abs(np.corrcoef(corrected.factors().iloc[:, k], b[:, 0])[0, 1]) for k in range(3)
    )
    assert r_naive > 0.6, f"test is not exercising anything, r_naive={r_naive:.2f}"
    assert r_corr < 0.3, f"batch not absorbed, r_corr={r_corr:.2f}"


def test_impute_leaves_observed_values_untouched():
    Ym, *_ = synth(seed=5)
    g = GMF(Ym)
    g.fit(d=3, max_iter=200)
    out = g.impute(only_missing=True)
    obs = Ym.notna().to_numpy()
    assert np.allclose(out.to_numpy()[obs], Ym.to_numpy()[obs])
    assert np.isfinite(out.to_numpy()).all()
    # only_missing=False replaces everything with the model surface
    assert not np.allclose(g.impute(only_missing=False).to_numpy()[obs],
                           Ym.to_numpy()[obs])


def test_masked_values_do_not_leak_into_the_fit():
    Ym, *_ = synth(seed=6)
    a = GMF(Ym); a.fit(d=2, max_iter=150)
    Y2 = Ym.copy()
    Y2 = Y2.mask(Ym.isna())          # same mask, values behind it irrelevant
    b = GMF(Y2); b.fit(d=2, max_iter=150)
    assert np.allclose(a.factors().to_numpy(), b.factors().to_numpy())


def test_residuals_are_nan_where_unobserved():
    Ym, *_ = synth(seed=7)
    g = GMF(Ym)
    g.fit(d=2, max_iter=150)
    r = g.residuals()
    assert np.array_equal(np.isnan(r.to_numpy()), np.isnan(Ym.to_numpy()))


def test_fit_cv_end_to_end():
    Ym, *_ = synth(rank=2, noise=0.3, missing=0.12, seed=8)
    g = GMF(Ym)
    fit, cv = g.fit_cv([1, 2, 3, 5], n_folds=2, hold_frac=0.2,
                       max_iter=50, verbose=False)
    assert fit.d == cv.best_rank
    assert g.factors().shape == (Ym.shape[1], fit.d)
    assert g.loadings().shape == (Ym.shape[0], fit.d)
    assert fit.proportion_variance.sum() == pytest.approx(1.0)
