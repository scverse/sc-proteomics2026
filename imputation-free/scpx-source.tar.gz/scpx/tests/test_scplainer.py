import numpy as np
import pandas as pd
import pytest
from scipy import stats

from scpx import ScpModel
from scpx.scplainer import benjamini_hochberg


def toy(n_feat=60, n_per_group=15, effect=2.0, missing=0.0, seed=0):
    rng = np.random.default_rng(seed)
    groups = np.array(["A"] * n_per_group + ["B"] * n_per_group)
    n = len(groups)
    base = rng.normal(20, 2, n_feat)[:, None]
    delta = np.zeros(n_feat)
    delta[: n_feat // 3] = effect
    Y = base + (groups == "A") * delta[:, None] + rng.normal(0, 0.3, (n_feat, n))
    if missing:
        Y[rng.random(Y.shape) < missing] = np.nan
    cols = [f"c{i}" for i in range(n)]
    Yd = pd.DataFrame(Y, index=[f"p{i}" for i in range(n_feat)], columns=cols)
    cd = pd.DataFrame({"group": groups, "depth": Yd.notna().sum(axis=0).to_numpy()},
                      index=cols)
    return Yd, cd, delta


def test_ridge_matches_ols_on_complete_data():
    """lambda = 1e-3 is small enough that coefficients track OLS closely."""
    Y, cd, _ = toy()
    m = ScpModel(Y, cd, "~ 1 + group")
    X = m.design.X
    for f in Y.index[:10]:
        ols, *_ = np.linalg.lstsq(X, Y.loc[f].to_numpy(), rcond=None)
        assert np.allclose(m.fits[f].coefficients, ols, atol=1e-3)


def test_intercept_only_beta_is_the_feature_mean():
    """The degenerate case the paper's design matrix is meant to avoid."""
    Y, cd, _ = toy(missing=0.2, seed=4)
    m = ScpModel(Y, cd, "~ 1")
    for f in list(Y.index)[:10]:
        assert m.fits[f].coefficients[0] == pytest.approx(
            np.nanmean(Y.loc[f].to_numpy()), rel=1e-4
        )


def test_fit_uses_only_observed_cells():
    """A feature's fit must equal the fit on its observed cells alone.

    This is the property that makes the method imputation-free: nothing at a
    masked position can influence any coefficient.
    """
    Y, cd, _ = toy(missing=0.25, seed=5)
    m = ScpModel(Y, cd, "~ 1 + group")
    X = m.design.X
    for f in list(m.kept_features)[:15]:
        y = Y.loc[f].to_numpy()
        keep = np.isfinite(y)
        lam = m.ridge_lambda
        Xi = X[keep]
        beta = np.linalg.solve(Xi.T @ Xi + lam * np.eye(Xi.shape[1]), Xi.T @ y[keep])
        assert np.allclose(m.fits[f].coefficients, beta)
        assert m.fits[f].n_obs == int(keep.sum())


def test_np_ratio_filter():
    Y, cd, _ = toy(n_feat=20, n_per_group=6, missing=0.0)
    Y.iloc[0, 2:10] = np.nan          # 4 observed of 12, spanning both groups
    Y.iloc[1, 1:] = np.nan            # 1 observed: fewer obs than parameters
    m = ScpModel(Y, cd, "~ 1 + group", np_threshold=3.0)
    assert m.fits["p0"].n_obs == 4
    assert m.fits["p0"].np_ratio == pytest.approx(2.0)
    assert "p0" not in m.kept_features        # 2.0 < threshold 3.0
    assert "p1" not in m.fits                 # never fitted at all
    assert m.np_ratios().loc["p2"] == pytest.approx(6.0)
    assert np.isnan(m.np_ratios().loc["p1"])


def test_variance_decomposition_sums_to_100():
    """With the default denominator the terms must partition exactly."""
    Y, cd, _ = toy(missing=0.15, seed=6)
    m = ScpModel(Y, cd, "~ 1 + group + depth")
    v = m.variance_analysis()
    tot = v.groupby("feature")["percent_explained_var"].sum()
    assert np.allclose(tot.to_numpy(), 100.0, atol=1e-6)
    assert set(v["effect"]) == {"Residuals", "group", "depth"}


def test_variance_finds_the_real_effect():
    """Features with a planted group effect must attribute more variance to
    group than features without one."""
    Y, cd, delta = toy(n_feat=60, effect=3.0, seed=8)
    m = ScpModel(Y, cd, "~ 1 + group")
    v = m.variance_analysis()
    g = v[v["effect"] == "group"].set_index("feature")["percent_explained_var"]
    has = g.loc[[f"p{i}" for i in np.flatnonzero(delta > 0)]].median()
    hasnt = g.loc[[f"p{i}" for i in np.flatnonzero(delta == 0)]].median()
    assert has > 80 and hasnt < 20


def test_differential_matches_t_test_on_complete_data():
    """For ~ 1 + group with no missing values, the contrast test must
    reproduce a pooled-variance two-sample t-test."""
    Y, cd, _ = toy(n_feat=30, missing=0.0, seed=9)
    m = ScpModel(Y, cd, "~ 1 + group")
    da = m.differential_analysis("group", "A", "B").set_index("feature")
    a = Y.loc[:, (cd["group"] == "A").to_numpy()]
    b = Y.loc[:, (cd["group"] == "B").to_numpy()]
    for f in Y.index:
        t = stats.ttest_ind(a.loc[f], b.loc[f], equal_var=True)
        assert da.loc[f, "estimate"] == pytest.approx(
            a.loc[f].mean() - b.loc[f].mean(), abs=1e-3)
        assert da.loc[f, "pvalue"] == pytest.approx(t.pvalue, rel=1e-3)


def test_differential_recovers_planted_effects():
    Y, cd, delta = toy(n_feat=90, effect=2.0, missing=0.2, seed=11)
    m = ScpModel(Y, cd, "~ 1 + group")
    da = m.differential_analysis("group", "A", "B").set_index("feature")
    truth = pd.Series(delta > 0, index=Y.index)
    called = da["padj"] < 0.05
    tp = int((called & truth.reindex(called.index)).sum())
    fp = int((called & ~truth.reindex(called.index)).sum())
    assert tp >= 0.9 * truth.sum()
    # BH controls the expected false discovery *proportion*, not the count;
    # demanding zero would be testing luck, not the method.
    assert fp <= max(1, int(0.05 * called.sum()))
    # sign and magnitude of the estimate
    sub = da.loc[truth[truth].index.intersection(da.index), "estimate"]
    assert sub.median() == pytest.approx(2.0, abs=0.2)


def test_apca_effect_plus_residuals_equals_input_for_single_factor():
    """APCA on the only effect of a one-factor model runs on effect+residual,
    which for an intercept-free-of-other-terms design is the centred data."""
    Y, cd, _ = toy(n_feat=40, missing=0.1, seed=12)
    m = ScpModel(Y, cd, "~ 1 + group")
    eff = m.effect("group")
    res = m.residuals()
    icpt = m.intercepts()
    total = eff.add(res).add(icpt, axis=0)
    obs = m.input().loc[m.kept_features]
    assert np.allclose(total.to_numpy()[np.isfinite(obs.to_numpy())],
                       obs.to_numpy()[np.isfinite(obs.to_numpy())], atol=1e-6)


def test_component_analysis_keys_and_shapes():
    Y, cd, _ = toy(missing=0.12, seed=13)
    m = ScpModel(Y, cd, "~ 1 + group + depth")
    res = m.component_analysis(ncomp=3, method="APCA")
    assert set(res) == {"unmodelled", "residuals", "APCA_group", "APCA_depth"}
    for r in res.values():
        assert r.scores.shape == (Y.shape[1], 3)
    sf = m.scores_frame(res["APCA_group"])
    assert "group" in sf.columns and sf.shape[0] == Y.shape[1]


def test_remove_batch_effect_keeps_missingness():
    Y, cd, _ = toy(missing=0.2, seed=14)
    m = ScpModel(Y, cd, "~ 1 + group")
    out = m.remove_batch_effect()
    obs = m.input().loc[m.kept_features]
    assert np.array_equal(np.isnan(out.to_numpy()), np.isnan(obs.to_numpy()))


def test_benjamini_hochberg_matches_reference():
    p = np.array([0.001, 0.008, 0.039, 0.041, 0.042, 0.06, 0.074, 0.205, np.nan])
    adj = benjamini_hochberg(p)
    expect = np.array([0.008, 0.032, 0.0672, 0.0672, 0.0672, 0.08, 0.0845714, 0.205])
    assert np.allclose(adj[:8], expect, atol=1e-6)
    assert np.isnan(adj[8])


def test_repr_is_informative():
    Y, cd, _ = toy()
    assert "formula" in repr(ScpModel(Y, cd, "~ 1 + group"))
